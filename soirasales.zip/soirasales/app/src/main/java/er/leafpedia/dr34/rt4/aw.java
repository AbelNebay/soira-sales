package er.leafpedia.dr34.rt4;

import com.aa.aaa.ResultPointCallback;

public interface aw extends ResultPointCallback {

    void onDecodeSuccess(String formatted, aq source);

    void onDecodeFailed(aq source);
}
