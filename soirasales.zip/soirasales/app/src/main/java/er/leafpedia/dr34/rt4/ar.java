package er.leafpedia.dr34.rt4;

import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import er.leafpedia.dr34.camera.Size;


public class ar extends aq {
    private byte[] yuvData;
    private Size dataSize;
    private Rect previewRect;

    public ar(byte[] yuvData, @NonNull Size dataSize, @NonNull Rect previewRect) {
        super(previewRect.width(), previewRect.height());
        if (previewRect.left + previewRect.width() > dataSize.width || previewRect.top + previewRect.height() > dataSize.height) {
            throw new IllegalArgumentException("Crop rectangle does not fit within image data.");
        }
        this.yuvData = yuvData;
        this.dataSize = dataSize;
        this.previewRect = previewRect;
    }
    @Nullable
    @Override
    public byte[] getRow(int y, @Nullable byte[] row) {
        if (y < 0 || y >= getHeight()) {
            throw new IllegalArgumentException("Requested row is outside the image: " + y);
        }
        int width = getWidth();
        if (row == null || row.length < width) {
            row = new byte[width];
        }
        int offset = (y + previewRect.top) * dataSize.width + previewRect.left;
        System.arraycopy(yuvData, offset, row, 0, width);
        return row;
    }
    @Override
    public byte[] getMatrix() {
        int width = getWidth();
        int height = getHeight();
        if (width == dataSize.width && height == dataSize.height) {
            return yuvData;
        }
        int area = width * height;
        byte[] matrix = new byte[area];
        int inputOffset = previewRect.top * dataSize.width + previewRect.left;
        if (width == dataSize.width) {
            System.arraycopy(yuvData, inputOffset, matrix, 0, area);
            return matrix;
        }
        byte[] yuv = yuvData;
        for (int y = 0; y < height; y++) {
            int outputOffset = y * width;
            System.arraycopy(yuv, inputOffset, matrix, outputOffset, width);
            inputOffset += dataSize.width;
        }
        return matrix;
    }
    @Override
    public boolean isCropSupported() {
        return true;
    }

    public int getDataWidth() {
        return dataSize.width;
    }

    public int getDataHeight() {
        return dataSize.height;
    }

}
