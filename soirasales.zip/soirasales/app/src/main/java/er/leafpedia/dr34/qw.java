package er.leafpedia.dr34;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aa.aaa.ResultPoint;
import com.aa.aaa.aaa.aztec.encoder.AztecCode;
import com.aa.aaaa.aaa.BinaryBitmap;
import com.aa.aaaa.aaa.MultiFormatReader;
import com.aa.aaaa.aaa.NotFoundException;
import com.aa.aaaa.aaa.RGBLuminanceSource;
import com.aa.aaaa.aaa.Result;
import com.aa.aaaa.aaa.common.HybridBinarizer;
import com.soira.soirasales.R;
import com.soira.soirasales.a6r.aa;
import com.aa.aaaa.aaa.pdf417.decoder.ec.k;
import com.soira.soirasales.gf3.l;
import com.soira.soirasales.sq3.SoiraButton;

import java.io.File;
import java.util.ArrayList;

import er.leafpedia.dr34.camera.CameraManager;
import er.leafpedia.dr34.camera.PreviewFrameShotListener;
import er.leafpedia.dr34.camera.Size;
import er.leafpedia.dr34.rt4.PathUtil;
import er.leafpedia.dr34.rt4.awe;
import er.leafpedia.dr34.rt4.aq;
import er.leafpedia.dr34.rt4.aw;
import er.leafpedia.dr34.rt4.ar;
import er.leafpedia.dr34.aq2.as;

import static com.aa.aaa.aaa.common.detector.b.EXPIRED;
import static com.aa.aaa.aaa.common.detector.b.INVALID;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_OPTION;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_SOIRA;

@SuppressWarnings("ALL")
public class qw extends AppCompatActivity implements SurfaceHolder.Callback, PreviewFrameShotListener, aw, OnClickListener {
    Typeface font;
    private static final long VIBRATE_DURATION = 200L;
    public static final String EXTRA_RESULT = "result";
    RelativeLayout root;
    private as as;
    private CameraManager cameraManager;
    @Nullable
    private awe mAwe;
    @Nullable
    private Rect previewFrameRect = null;
    private boolean isDecoding = false;
    TextView scan_text;

    RelativeLayout please_wait;

    SoiraButton open_gallery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ad);
        root = (RelativeLayout) findViewById(R.id.root_layout);
        font = Typeface.createFromAsset(getAssets(), "soira_font.ttf");
        open_gallery = (SoiraButton) findViewById(R.id.open_gallery);
        please_wait = (RelativeLayout) findViewById(R.id.please_wait);
        please_wait.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // nothing...
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }else {
            root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        }

        root.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                }else {
                    root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
                }
            }
        });
        final SurfaceView previewSv = (SurfaceView) findViewById(R.id.sv_preview);
        as = (as) findViewById(R.id.cv_capture);
        ImageButton backBtn = (ImageButton) findViewById(R.id.btn_back);
        scan_text = (TextView) findViewById(R.id.scan_text);
        scan_text.setTypeface(font);

        backBtn.setOnClickListener(this);
        previewSv.getHolder().addCallback(this);
        cameraManager = new CameraManager(this);
        cameraManager.setPreviewFrameShotListener(this);

        open_gallery.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (flip == 0){
//                    flip = 1;
//                }else{
//                    flip = 0;
//                }
//                initialize_camera(previewSv.getHolder(), flip);
                opera(444);


            }
        });

    }

    private void opera(int which_one){
        String[] mime = {"image/*"};
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.setType("*/*");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && which_one != 300) {
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mime);
        }
        startActivityForResult(intent, which_one);
    }


    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        initialize_camera(holder, flip);
    }

    int flip = 0;

    private void initialize_camera(SurfaceHolder holder, int option) {
        if (holder == null) return;
        cameraManager.initCamera(holder, option);
        if (!cameraManager.isCameraAvailable()) {
            Toast.makeText(qw.this, "Camera is not found. Use local file selection.", Toast.LENGTH_LONG).show();

            // TODO: 7/10/2023 Will check the options for finishing the acitivty

//            finish(); // No need for this option...


            // TODO: 7/10/2023 The upper function is to be mentioned later
            return;
        }
        cameraManager.startPreview();
        if (!isDecoding) {
            cameraManager.requestPreviewFrameShot();
        }
    }

    @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        cameraManager.stopPreview();
        if (mAwe != null) {
            mAwe.cancel();
        }
        cameraManager.release();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPreviewFrame(byte[] data, @NonNull Size dataSize) {
        if (mAwe != null) {
            mAwe.cancel();
        }
        if (previewFrameRect == null) {
            previewFrameRect = cameraManager.getPreviewFrameRect(as.getFrameRect());
        }
        ar luminanceSource = new ar(data, dataSize, previewFrameRect);
        mAwe = new awe(luminanceSource, qw.this);
        isDecoding = true;
        mAwe.execute();
    }

    private void makeVibranium(){
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(VIBRATE_DURATION);
    }

    @Override
    public void onDecodeSuccess(String result, aq source) {
        makeVibranium();
        isDecoding = false;
        Intent resultData = new Intent();
        resultData.putExtra(EXTRA_RESULT, result);
        setResult(RESULT_OK, resultData);
        SELECTED_PATH = null;
        k.DATA_FETCHED = null;
        finish();
    }

    @Override
    public void onDecodeFailed(aq source) {
        isDecoding = false;
        if (EXPIRED){
            makeVibranium();
            EXPIRED = false;
            Toast.makeText(this, "QR Code is expired!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }else if (INVALID){
            makeVibranium();
            INVALID = false;
            Toast.makeText(this, "QR Code is invalid.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        cameraManager.requestPreviewFrameShot();
    }

    @Override
    public void foundPossibleResultPoint(@NonNull ResultPoint point) {
        as.addPossibleResultPoint(point);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

        @Override
        public void onClick(@NonNull View v) {
            switch (v.getId()) {
                case R.id.btn_back:
                    finish();
                    break;
                case R.id.local_button:
                    local_selector();
                    break;
           }
        }

    private void local_selector() {
        EXPLORER_OPTION = EXPLORER_SOIRA;
        startActivity(new Intent(qw.this, aa.class));
    }

    class Turbo extends AsyncTask<ArrayList<String>, Void, ArrayList<Result>>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            try {
                cameraManager.stopPreview();
            }catch (Exception e){}
            please_wait.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(ArrayList<Result> results) {
            super.onPostExecute(results);
            if (results == null){
                Toast.makeText(qw.this, "Unable to read QR Image.", Toast.LENGTH_SHORT).show();
                please_wait.setVisibility(View.GONE);
                try {
                    cameraManager.startPreview();
                }catch (Exception e){}
                return;
            }
            ArrayList<String> refined = new ArrayList<>();
            for (Result result: results){
                String resulted_id = result.getText();
                try {
                    resulted_id = AztecCode.a(resulted_id);
                }catch (Exception e){
                    resulted_id = "null";
                }
                String[] values =  resulted_id.split(":");
                if (values.length == 3 && values[0].equals("soira_files")){
                    refined.add(resulted_id);
                }

            }
            if (refined.isEmpty()){
                please_wait.setVisibility(View.GONE);
                Toast.makeText(qw.this, "Invalid QR Code Image.", Toast.LENGTH_SHORT).show();
                try {
                    cameraManager.startPreview();
                }catch (Exception e){}
                return;
            }
            makeVibranium();
            isDecoding = false;
            Intent resultData = new Intent();
            resultData.putExtra(EXTRA_RESULT, refined);
            setResult(RESULT_OK, resultData);
            SELECTED_PATH = null;
            k.DATA_FETCHED = null;
            please_wait.setVisibility(View.GONE);
            finish();
        }

        @Override
        protected ArrayList<Result> doInBackground(ArrayList<String>... params) {
            ArrayList<String> paths = params[0];
            ArrayList<Result> results = new ArrayList<>();
            for (String path: paths){
                Bitmap bitmap = BitmapFactory.decodeFile(path);
                if (bitmap == null)return null;
                int width = bitmap.getWidth(), height = bitmap.getHeight();
                int[] pixels = new int[width*height];
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
                bitmap.recycle();
                bitmap = null;
                RGBLuminanceSource luminanceSource = new RGBLuminanceSource(width, height, pixels);
                BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
                MultiFormatReader reader = new MultiFormatReader();
                Result result = null;
                try{
                    result = reader.decode(binaryBitmap);
                    results.add(result);
                }catch (NotFoundException e) {}
            }
            if (results.isEmpty())return null;
            return results;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @NonNull Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 444 && resultCode == -1){
            if (data == null){
                Toast.makeText(this, "Unable to get the data.", Toast.LENGTH_SHORT).show();
                return;
            }
            ArrayList<String> paths = new ArrayList<>();
            if (data.getClipData() != null){
                ClipData clipData = data.getClipData();
                for (int i = 0; i < clipData.getItemCount(); i++){
                    Uri uri = clipData.getItemAt(i).getUri();
                    String path = PathUtil.getUtil(qw.this, uri);
                    paths.add(path);
                }
            }else {
                if (data.getData() != null){
                    paths.add(PathUtil.getUtil(qw.this, data.getData()));
                }else {
                    Toast.makeText(this, "Unable to get the data.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            if (paths.isEmpty()){
                Toast.makeText(this, "No valid paths is selected.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (turbo != null){
                turbo.cancel(true);
                turbo = null;
            }
            turbo = new Turbo();
            turbo.execute(paths);
            return;
        }
        if (requestCode == 777 && resultCode == -1){
            String path = l.getUtil(qw.this, data.getData());
            String newPath = new File(path).getParent();
            SELECTED_PATH = newPath;
            finish();
        }
    }


    Turbo turbo;
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (turbo != null){
            turbo.cancel(true);
            turbo = null;
        }
    }

    @Nullable
    public static String SELECTED_PATH = null;
}

