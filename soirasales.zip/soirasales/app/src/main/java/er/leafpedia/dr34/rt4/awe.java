package er.leafpedia.dr34.rt4;

import android.content.Context;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.annotation.Nullable;

import com.aa.aaa.BinaryBitmap;
import com.aa.aaa.DecodeHintType;
import com.aa.aaa.MultiFormatReader;
import com.aa.aaa.ReaderException;
import com.aa.aaa.Result;
import com.aa.aaa.aaa.aztec.encoder.AztecCode;
import com.aa.aaa.aaa.datamatrix.encoder.a;
import com.aa.aaa.common.HybridBinarizer;
import com.aa.aaa.aaa.common.detector.b;
import com.aa.aaaa.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.ki;

import java.util.Hashtable;

import static android.content.Context.MODE_PRIVATE;
import static com.aa.aaa.aaa.datamatrix.encoder.a.DEVICE_ID;

public class awe extends AsyncTask<Void, Void, Result> {
    private aq aq;
    private aw listener;
    private boolean isStop = false;
    private Context context;

    public awe(aq aq, aw listener) {
        this.aq = aq;
        this.listener = listener;
        this.context = (Context) listener;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        a.fetch_security(this.context);
    }

    @Nullable
    @Override
    protected Result doInBackground(Void... params) {
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(aq));
        Hashtable<DecodeHintType, Object> hints = new Hashtable<DecodeHintType, Object>(3);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.NEED_RESULT_POINT_CALLBACK, listener);
        MultiFormatReader multiFormatReader = new MultiFormatReader();
        multiFormatReader.setHints(hints);
        Result rawResult = null;
        try {
            rawResult = multiFormatReader.decodeWithState(bitmap);
        } catch (ReaderException ignored) {
        } finally {
            multiFormatReader.reset();
        }
        return rawResult;
}
    @Override
    protected void onPostExecute(@Nullable Result result) {
        DEVICE_ID = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        b.DEVICE_NAME = context.getSharedPreferences(b.INTRO, MODE_PRIVATE).getString(b.DEVICE_SET, b.getDeviceModel());
        if (listener != null && !isStop) {
            if (result == null) {
                listener.onDecodeFailed(aq);
            } else {
                String resulted_id = result.getText();
                try {
                    resulted_id = AztecCode.a(resulted_id);
                }catch (Exception e){
                    resulted_id = "null";
                }
                String[] values =  resulted_id.split(":");
                if (values.length == 3 && values[0].equals(ki.qaq("tpjsb`gjmft"))){
                    listener.onDecodeSuccess(resulted_id, aq);
                }else {
                    listener.onDecodeFailed(aq);
                }

            }
        }
    }

    public void cancel() {
        isStop = true;
        cancel(true);
    }
}
 