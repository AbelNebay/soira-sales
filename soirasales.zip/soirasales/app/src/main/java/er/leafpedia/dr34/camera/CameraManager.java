package er.leafpedia.dr34.camera;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.WindowManager;

import java.io.IOException;
import java.util.List;

@SuppressWarnings("ALL")
public class CameraManager implements Camera.AutoFocusCallback, Camera.PreviewCallback {

    private enum CameraState {
        CLOSED, OPEN, PREVIEW;
    }

    private Camera mCamera;
    private Size screenSize;
    private Size cameraSize;
    private CameraState mState;
    private PreviewFrameShotListener mFrameShotListener;
    private static final int REQUEST_AUTO_FOCUS_INTERVAL_MS = 1500;
    private static final int MESSAGE_REQUEST_AUTO_FOCUS = 0;

    @Nullable
    private Handler mHandler = new Handler() {
        public void handleMessage(@NonNull android.os.Message msg) {
            switch (msg.what) {
                case MESSAGE_REQUEST_AUTO_FOCUS:
                    if (mState == CameraState.PREVIEW && mCamera != null) {
                        try {
                            mCamera.autoFocus(CameraManager.this);
                        }catch (RuntimeException ignored){
                        }
                    }
                    break;
                default:
                    break;
            }
        };
    };

    public CameraManager(@NonNull Context context) {
        WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = manager.getDefaultDisplay();
        screenSize = new Size(display.getWidth(), display.getHeight());
        mState = CameraState.CLOSED;
    }
    public boolean initCamera(SurfaceHolder holder, int option) {
        int count = Camera.getNumberOfCameras();
        if (count == 0){
            return false;
        }
        if (mCamera != null){
            mCamera.release();
        }
        switch (option){
            case 1:
                if (count > 1) {
                    mCamera = Camera.open(1);
                }else {
                    mCamera = Camera.open();
                }
                break;
            default:
                mCamera = Camera.open();
        }

//        mCamera = Camera.open(); // No more_dark permission error ma baby, stay cool, I just handled it for you!
        if (mCamera == null) {
            return false;
        }
        mState = CameraState.OPEN;
        mCamera.setDisplayOrientation(90);
        Camera.Parameters parameters = mCamera.getParameters();
        cameraSize = getBestPreviewSize(parameters, screenSize);
        parameters.setPreviewSize(cameraSize.height, cameraSize.width);
        parameters.setPreviewFormat(ImageFormat.NV21);//Default
        mCamera.setParameters(parameters);
        try {
            mCamera.setPreviewDisplay(holder);
        } catch (IOException e) {
            return false;
        }
        return true;
    }
    public boolean isCameraAvailable() {
        return mCamera == null ? false : true;
    }

    public void startPreview() {
        if (mCamera != null) {
            mState = CameraState.PREVIEW;
            mCamera.startPreview();
            mCamera.autoFocus(CameraManager.this);
        }
    }
    public void stopPreview() {
        if (mCamera != null) {
            mCamera.stopPreview();
            mState = CameraState.OPEN;
        }
    }
    public void release() {
        if (mCamera != null) {
            mCamera.setOneShotPreviewCallback(null);
            mCamera.release();
            mState = CameraState.CLOSED;
        }
    }
    public void requestPreviewFrameShot() {
        mCamera.setOneShotPreviewCallback(CameraManager.this);
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        if (mFrameShotListener != null) {
            data = rotateYUVdata90(data);
            mFrameShotListener.onPreviewFrame(data, cameraSize);
        }
    }

    @NonNull
    private Size getBestPreviewSize(@NonNull Camera.Parameters parameters, @NonNull Size screenSize) {
        Size size = new Size(screenSize);
        int diff = Integer.MAX_VALUE;
        List<Camera.Size> previewList = parameters.getSupportedPreviewSizes();
        for (Camera.Size previewSize : previewList) {
            // Rotate 90 degrees
            int previewWidth = previewSize.height;
            int previewHeight = previewSize.width;
            int newDiff = Math.abs(previewWidth - screenSize.width) * Math.abs(previewWidth - screenSize.width)
                    + Math.abs(previewHeight - screenSize.height) * Math.abs(previewHeight - screenSize.height);
            if (newDiff == 0) {
                size.width = previewWidth;
                size.height = previewHeight;
                return size;
            } else if (newDiff < diff) {
                diff = newDiff;
                size.width = previewWidth;
                size.height = previewHeight;
            }
        }
        return size;
    }


    @NonNull
    public Rect getPreviewFrameRect(@NonNull Rect screenFrameRect) {
        if (mCamera == null) {
            throw new IllegalStateException("Need to call initCamera() before this you kid. Stay cool!");
        }
        Rect previewRect = new Rect();
        previewRect.left = screenFrameRect.left * cameraSize.width / screenSize.width;
        previewRect.right = screenFrameRect.right * cameraSize.width / screenSize.width;
        previewRect.top = screenFrameRect.top * cameraSize.height / screenSize.height;
        previewRect.bottom = screenFrameRect.bottom * cameraSize.height / screenSize.height;
        return previewRect;
    }
    @NonNull
    private byte[] rotateYUVdata90(@NonNull byte[] srcData) {
        byte[] desData = new byte[srcData.length];
        int srcWidth = cameraSize.height;
        int srcHeight = cameraSize.width;
        // Only copy Y values: because that value the only needed parameter to get the peculiar values that is needed to draw QR Code, it is better to consder this is dedicated for the one I love most: She is SHE!
        int i = 0;
        for (int x = 0; x < srcWidth; x++) {
            for (int y = srcHeight - 1; y >= 0; y--) {
                desData[i++] = srcData[y * srcWidth + x];
            }
        }
        return desData;
    }
    @Override
    public void onAutoFocus(boolean success, Camera camera) {
        if (mState == CameraState.PREVIEW) {
            mHandler.sendEmptyMessageDelayed(MESSAGE_REQUEST_AUTO_FOCUS, REQUEST_AUTO_FOCUS_INTERVAL_MS);
        }
    }
    public void setPreviewFrameShotListener(PreviewFrameShotListener l) {
        mFrameShotListener = l;
    }
}
