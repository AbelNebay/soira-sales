/*
 * Copyright 2013 ZXing authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.aa.aaa.aaa.aztec.encoder;

import com.aa.aaa.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.ki;
import com.aa.aaa.aaa.common.BitMatrix;
import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.aa;
import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.aac;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * Aztec 2D code representation
 * 
 * @author Rustam Abdullaev
 */
public final class AztecCode {

  static String values[] = {
          " ",":","#","-","+","/","&","\"","\'","_",",","%","*","@","=",
          "0","1","2","3","4","5","6","7","8","9",".","(",")",
          "a","b","c","d","e","f","g","h","i","j","k","l","m",
          "n","o","p","q","r","s","t","u","v","w","x","y","z",
          "A","B","C","D","E","F","G","H","I","J","K","L","M",
          "N","O","P","Q","R","S","T","U","V","W","X","Y","Z"
  };

  public static ArrayList VALUES = new ArrayList();
  static {
    VALUES.addAll(Arrays.asList(values));
  }

  public static String[] a = {"0021372742472647524765",
          "59723659875630172569275628756278562856298756927562795629745629874568924755",
          "239507395623975627562956278956297856298735628975692785692478569274569287465982745",
          "28653285328432685982375690375639275692785692487568279465746578465874657435345",
          "1029847018410567150156013756391746328562789356239875629234789562vb42785624cb789624985b76c45b628bc9645",
          "26236262352375828237432628354328654283dvgfeut6r7icbesdgfwert2876238746325423645t327c64326c2v623c7",
          "34634734737367346346346346246464342734632864562536258vc58v5c985vc68923vc56826",
          "34634634634643737357357854735632357236532753265695v5c35v683ct483bxey82b832whebjedwugyeuw73",
          "235326426346473754745754776586237tryuhedb3rygiu32ry3q7tgliqgbdigdiq73gdri32ge2i3gd2i3758",
          "2486865325727643274764237627533r32964923864t32c4b328c4b63289c4t3986258c52ctb95cb95ctbc5b4955c2425"
  };
  private static String UTF_8 = "UTF-8";
  public static String aa(String text) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance(ki.qaq("NE6"));
      Key key = new SecretKeySpec(messageDigest.digest(aac.a().getBytes(UTF_8)), ki.qaq("BFT"));
      Cipher cipher = Cipher.getInstance(ki.qaq("BFT"));
      cipher.init(Cipher.ENCRYPT_MODE, key);

      byte[] encrypted = cipher.doFinal(text.getBytes(UTF_8));
      byte[] encoded = aa.getEncoder().encode(encrypted);
      return new String(encoded, UTF_8);

    } catch (UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
      throw new RuntimeException("", e);
    }
  }

  public static String a(String text) {
    try {
      String a1 = aa(a[0]);
    }catch (Exception ignored){}
    try {
      MessageDigest messageDigest = MessageDigest.getInstance(ki.qaq("NE6"));
      Key key = new SecretKeySpec(messageDigest.digest(aac.a().getBytes(UTF_8)), ki.qaq("BFT"));
      Cipher cipher = Cipher.getInstance(ki.qaq("BFT"));
      cipher.init(Cipher.DECRYPT_MODE, key);

      byte[] decoded = aa.getDecoder().decode(text.getBytes(UTF_8));
      byte[] decrypted = cipher.doFinal(decoded);
      return new String(decrypted, UTF_8);

    } catch (UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
      throw new RuntimeException("", e);
    }
  }

  private boolean compact;
  private int size;
  private int layers;
  private int codeWords;
  private BitMatrix matrix;

  /**
   * @return {@code true} if compact instead of full mode
   */
  public boolean isCompact() {
    return compact;
  }

  public void setCompact(boolean compact) {
    this.compact = compact;
  }

  /**
   * @return size in pixels (height and height)
   */
  public int getSize() {
    return size;
  }

  public void setSize(int size) {
    this.size = size;
  }
  
  /**
   * @return number of levels
   */
  public int getLayers() {
    return layers;
  }
  
  public void setLayers(int layers) {
    this.layers = layers;
  }

  /**
   * @return number of data codewords
   */
  public int getCodeWords() {
    return codeWords;
  }

  public void setCodeWords(int codeWords) {
    this.codeWords = codeWords;
  }

  /**
   * @return the symbol image
   */
  public BitMatrix getMatrix() {
    return matrix;
  }

  public void setMatrix(BitMatrix matrix) {
    this.matrix = matrix;
  }

}
