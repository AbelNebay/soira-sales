package com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders;


public class aac {

    public static String a(){
        IIIIIIIII();
        String value = IIIIIIIIIIIIIIIII["".length()];
        return value;
    }

    private static String[] I,IIIIIIII,IIIIIIIIIIIIIIIIIII,IIIIIIIIIIIIIIIII,IIIIIIIIIIIIIIIIII,IIIIIIIIIIIIIII,IIIIIIIIIIIIIIII;
    private static String I(String s, String s1) {
        StringBuilder sb = new StringBuilder();
        char[] key = s1.toCharArray();
        int i = "".length();
        char[] var5 = s.toCharArray();
        int var6 = var5.length;
        int var7 = "dddaIIIIIIIIIIIIIIIII".length();

        do {
            if(var7 >= var6) {
                return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
        } while(-1 == -1);

    }



    private static String IIIIIIIIIIIIIIIIIIIIIIIIII(String s, String s1) {
        StringBuilder sb = new StringBuilder();
        char[] key = s1.toCharArray();
        int i = "".length();
        char[] var5 = s.toCharArray();
        int var6 = var5.length;
        int var7 = "a".length();

        do {
            if(var7 >= var6) {
                return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
        } while(-1 == -1);

    }


    private static String IIIIIIIIIIIIIIIII(String s, String s1) {
        StringBuilder sb = new StringBuilder();
        char[] key = s1.toCharArray();
        int i = "".length();
        char[] var5 = s.toCharArray();
        int var6 = var5.length;
        int var7 = "".length();

        do {
            if(var7 >= var6) {
                return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
        } while(-1 == -1);

    }


    private static void I() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXE_Pa]D", "aTlrm");
    }

    private static void III() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\Xa]D", "aTlrm");
    }
    private static void IIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXE_Pasasada]D", "aTlrm");
    }
    private static void IIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XXE_Pa]D", "aTlrm");
    }
    private static void IIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXE_D", "aTlrm");
    }
    private static void IIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XD", "aTwefewfewlrm");
    }
    private static void IIIIIIIII() {
        IIIIIIIIIIIIIIIII = new String[" ".length()];
        IIIIIIIIIIIIIIIII["".length()] = IIIIIIIIIIIIIIIII("Qd^C\\XaXE_Pa]D", "aTlrm");
    }
    private static void IIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^Cfwefewff\\XaXE_Pa]D", "aTlrm");
    }
    private static void IIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXEwefewfew_Pa]D", "aTlrm");
    }
    private static void IIIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXEwefewfewf_Pa]D", "aTlrm");
    }
    private static void IIIIIIIIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXwefewfE_Pa]D", "aTlrm");
    }
    private static void IIIIIIeIIIIIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXE_Pa]Dwefewfwe", "aTlrm");
    }
    private static void IIIIIIIIIIIIIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXE_Pa]D", "aTlrm");
    }
    private static void IIIIIIIIIIIIIIIIIIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XewfewfewfaXE_Pa]D", "aTlrm");
    }
    private static void IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII() {
        I = new String[" ".length()];
        I["".length()] = I("Qd^C\\XaXE_Pa]D", "aTlrm");
    }

}