package com.aa.aaa.aaa.aztec;

/**
 * @author  Abel Nebay
 *          Biology IV - 2022
 *          Used a simple and fast trick for getiing the decimals out of bunched stupid decimal trails..
 * */
public class xx {

    public static String edit(double value){
        String characters = String.valueOf(value);
        if (characters.contains(".")){
            int dot_index = characters.indexOf(".");
            if (characters.length() == dot_index + 2){
                int firstArg = Integer.parseInt(String.valueOf(characters.charAt(dot_index + 1)));
                if (firstArg > 5){
                    int before = Integer.valueOf(characters.substring(0, dot_index));
                    before++;
                    characters = String.valueOf(before);
                    return characters;
                }else {
                    if (firstArg == 0){
                        characters = characters.substring(0, dot_index);
                        return characters;
                    }
                }
                characters = characters.substring(0, dot_index + 2);
            }else if (characters.length() > dot_index + 2){
                int secondArg = Integer.parseInt(String.valueOf(characters.charAt(dot_index + 2)));
                int firstArg = Integer.parseInt(String.valueOf(characters.charAt(dot_index + 1)));
                if (secondArg > 5){
                    if (firstArg == 9){
                        int before = Integer.valueOf(characters.substring(0, dot_index));
                        before++;
                        characters = String.valueOf(before);
                        return characters;
                    }
                    firstArg += 1;
                    characters = characters.substring(0, dot_index + 1) + String.valueOf(firstArg);
                }else {
                    if (firstArg == 0){
                        characters = characters.substring(0, dot_index);
                        return characters;
                    }
                    characters = characters.substring(0, dot_index + 2);

                }
            }
            else { // Which always doesn't occur in mathematics nature
                characters = characters.substring(0, dot_index);
            }
        }
        return characters;
    }
}
