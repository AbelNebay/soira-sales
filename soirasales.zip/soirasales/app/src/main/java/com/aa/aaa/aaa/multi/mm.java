package com.aa.aaa.aaa.multi;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * The below database helper is used to store the given path according to their newly added one!
 * &amp; setting_layout bit more_dark.... PEACE!
 * */
public class mm extends SQLiteOpenHelper{
    private static final String GRANTED = "GRANTED";


    private static final String DATABASE_NAME = "GRANTED.db";
    private final String TABLE_NAME;
    private static final String MEDIA_ID = "MEDIA_ID";
    private static final String GRANTED_VALUE = "GRANTED_VALUE";

    /**
     * mn constructor with
     * @param context
     * Author       : Abel Nebay
     * College      : Mai-Nefhi College of Science
     * Department   : Applied Biology IV Year
     * E-mail       : abelnebay555@gmail.com
     * Website      : https://www.leafpedia.com
     * Company      : Leaf Pedia, Inc.
     * Foundation   : SoiraPlayer, Inc.
     * Tel          : +291-7276-749
     * Year         : 2023 - Tesseney, Asmara - Eritrea, Norther East Africa @Earth {#3 Planet}
     * */
    mm(Context context, String TABLE_NAME) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = TABLE_NAME;
    }
    public mm(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = GRANTED;
    }

    /**
     * onCreate for creating the existing or new table by the name
     * */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + MEDIA_ID + " TEXT PRIMARY KEY, " + GRANTED_VALUE + " TEXT)");
    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
    }

    public Cursor getAllData(){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME, null);
    }

    private Cursor getCursorDataAt(String media_id){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("select * from " + TABLE_NAME + " where " + MEDIA_ID + "='" + media_id + "'", null);
        if (cursor != null && cursor.moveToFirst()){
            return cursor;
        }
        return null;
    }

    @Nullable
    public String getDataAt(String media_id){
        Cursor cursor = getCursorDataAt(media_id);
        if (cursor != null){
            return cursor.getString(1);
        }
        return null;
    }

    public boolean updateData(String media_id, String total_cash){
        Log.i("UPDATED", total_cash);
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(GRANTED_VALUE, total_cash);
        int result = database.update(TABLE_NAME, contentValues, MEDIA_ID + "=?", new String[]{media_id});
        database.close();
        return result > 0;
    }

    public boolean insertData(String media_id, String total_cash){
        Log.i("INSERTED", total_cash);
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MEDIA_ID, media_id);
        contentValues.put(GRANTED_VALUE, total_cash);
        long result = database.insert(TABLE_NAME, null, contentValues);
        database.close();
        return result != -1;
    }

    public boolean deleteData(String media_id){
        SQLiteDatabase database = this.getWritableDatabase();
        int i =  database.delete(TABLE_NAME, MEDIA_ID + "=?", new String[]{media_id});
        database.close();
        return i > 0;
    }

}
