package com.soira.soirasales.a10.a94;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;

import com.soira.soirasales.R;
import com.soira.soirasales.sq3.SoiraTextView;

import java.util.ArrayList;
import java.util.List;

public class a extends ArrayAdapter<String> {

    Context context;
    int resource, textViewResourceId;
    private List<String> items, tempItems;
    public static List<String> suggestions, original;

    public a(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<String> items) {
        super(context, resource, textViewResourceId, items);
        this.context = context;
        this.resource = resource;
        this.textViewResourceId = textViewResourceId;
        this.items = items;
        tempItems = new ArrayList<>(items); // this makes the difference.
        suggestions = new ArrayList<>();
        original = new ArrayList<>();
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, ViewGroup parent) {
        View view = convertView;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.qw, parent, false);
        }
        String name = items.get(position);
        if (name != null) {
            SoiraTextView label_text = (SoiraTextView) view.findViewById(R.id.lists_item_text);
            if (label_text != null) {
                String[] content = name.split(":");
                String formatted = content[2] + " - " + content[3];
                label_text.setText(formatted);
            }

        }
        return view;
    }

    @NonNull
    @Override
    public Filter getFilter() {
        return nameFilter;
    }

    /**
     * Custom Filter implementation for custom_small suggestions al provide.
     */
    @NonNull
    Filter nameFilter = new Filter() {
        @NonNull
        @Override
        public CharSequence convertResultToString(@NonNull Object resultValue) {
            return (String) resultValue;
        }

        @NonNull
        @Override
        protected FilterResults performFiltering(@Nullable CharSequence constraint) {
            if (constraint != null) {
                suggestions.clear();
                original.clear();
                for (String path : tempItems) {
                    try {
                        String[] value = path.split(":");
                        String counter = value[0] + ":" + value[2] + " - " + value[3];
                        if (counter.toLowerCase().contains(constraint.toString().toLowerCase())) {
                            if (suggestions.size() < 10) {
                                suggestions.add(path);
                            }
                            original.add(path);
                        }
                    }catch (Exception ignored){}
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = suggestions;
                filterResults.count = suggestions.size();
                return filterResults;
            } else {
                return new FilterResults();
            }
        }

        @Override
        protected void publishResults(CharSequence constraint, @NonNull FilterResults results) {
            try {
                List<String> filterList = (List<String>) results.values;
                if (results != null && results.count > 0) {
                    clear();
                    for (String names : filterList) {
                        add(names); // addAll(names) also can be used if bug is seen
                        notifyDataSetChanged();
                    }
                }
            }catch (Exception ignored){}
        }
    };
}