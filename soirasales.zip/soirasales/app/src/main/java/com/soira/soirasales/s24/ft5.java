package com.soira.soirasales.s24;


import java.io.File;

public interface ft5 {

    void onFound(String file);

    void onExplorer(File[] media);

}
