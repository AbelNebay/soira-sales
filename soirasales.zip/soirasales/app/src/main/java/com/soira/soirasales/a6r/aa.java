package com.soira.soirasales.a6r;


import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.soira.soirasales.R;
import com.soira.soirasales.a10.zx2.z0i;
import com.soira.soirasales.aqp.Keyboard;
import com.soira.soirasales.gf3.xxe;
import com.soira.soirasales.s24.ft5;
import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.qedf;
import com.aa.aaaa.aaa.pdf417.decoder.ec.k;
import com.soira.soirasales.gf3.xy;
import com.aa.aaaa.aaa.multi.m;
import com.soira.soirasales.sq3.SoiraAutoCompleteTextView;
import com.soira.soirasales.sq3.SoiraButton;
import com.soira.soirasales.sq3.SoiraTextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.aa.aaa.aaa.common.detector.b.LOCAL_PROCESSED;
import static com.aa.aaa.aaa.common.detector.b.QR_PROCESSED;
import static com.aa.aaa.aaa.common.detector.b.SOIRA_SALES;
import static com.aa.aaa.aaa.common.detector.b.SOIRA_WALL;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_DIR;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_OPTION;

public class aa extends AppCompatActivity{
    SoiraButton close_button;
    SoiraTextView path_info;
    RecyclerView path_lister;
    ImageView clear_text;
    RelativeLayout search_bar;
    SoiraAutoCompleteTextView search_stored;

    @Nullable
    File[] inited_paths;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qqq);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#111111"));
            getWindow().setStatusBarColor(Color.parseColor("#111111"));
        }
        init_views();
        init_listeners();
        init_storage();
        if (inited_paths != null && inited_paths.length > 0) {
            current_path = null;
            try {
                current_selection = inited_paths;
                setAdapter(inited_paths, false);
            }catch (Exception ignored){}
        }else{
            Toast.makeText(this, "File error.", Toast.LENGTH_SHORT).show();
        }
    }

    List<xy.StorageVolume> volume;
    private void init_storage() {
        volume = xy.getStorages(false);
        if (inited_paths != null) {
            inited_paths = null;
        }
        inited_paths = new File[volume.size()];
        for (int i = 0 ; i < volume.size(); i++){
            inited_paths[i] = volume.get(i).file;
        }
    }

    @Nullable
    z0i z0i;
    File[] current_selection;
    private void setAdapter(File[] user_media, boolean sort) {
        try {
            ArrayList<File> media_files = m.sort(user_media, sort);
            if (media_files == null) {
                return;
            }
            if (z0i != null) {
                z0i = null;
            }
            if (path_lister != null) {
                path_lister.setAdapter(null);
            }
            z0i = new z0i(this, media_files, new ft5() {
                @Override
                public void onFound(@NonNull String file) {
                    try {
                        k.DATA_FETCHED = qedf.Wec.far(k.getReadableString(file));
                        // FIXME: 3/31/2023 Encryption is required here.
                        if (k.DATA_FETCHED != null) {
                            if (k.DATA_FETCHED.startsWith(SOIRA_WALL)) {
                                xxe.TARGET = xxe.WALL;
                                try {
                                    new File(file).delete();
                                }catch (Exception ignored){}
                            } else if (k.DATA_FETCHED.startsWith(SOIRA_SALES)) {
                                xxe.TARGET = xxe.WALL;//xxe.SALES;
                                try {
                                    new File(file).delete();
                                }catch (Exception ignored){}

                            } else {
                                k.DATA_FETCHED = null;
                                Toast.makeText(aa.this, "File selected is invalid.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            LOCAL_PROCESSED = true;
                            QR_PROCESSED = false;
                            finish();

                        }
                    } catch (Exception e) {
                        k.DATA_FETCHED = null;
                        Toast.makeText(aa.this, "Error in local transaction.", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onExplorer(@Nullable File[] media) {
                    if (media == null) {
                        Toast.makeText(aa.this, "File error.", Toast.LENGTH_SHORT).show();
                        counter = 0;
                        current_path = null;
                        finish();
                        return;
                    }
                    counter += 1;
                    current_selection = media;
                    print_info();
                    setAdapter(media, true);
                }
            });
            path_lister.setLayoutManager(new LinearLayoutManager(this));
            path_lister.setAdapter(z0i);
        }catch (Exception ignored){}
    }

    private boolean delete_path(String dataFetched) {
        File file = new File(dataFetched);
        return file.exists() && file.delete();
    }

    private void deprint_info() {
        path_info.setEnabled(false);
        path_info.setText("/storage");
    }

    private void print_info() {
        path_info.setEnabled(true);
        if (!current_path.startsWith("/")){
            path_info.setText("/" + current_path);
            return;
        }
        path_info.setText(current_path);
    }

    private void init_views() {
        search_bar = (RelativeLayout) findViewById(R.id.search_bar);
        search_stored = (SoiraAutoCompleteTextView) findViewById(R.id.exp_search_query);
        path_lister = (RecyclerView) findViewById(R.id.path_lister);
        close_button = (SoiraButton) findViewById(R.id.close_button);
        path_info = (SoiraTextView) findViewById(R.id.path_info);
        clear_text = (ImageView) findViewById(R.id.clearImg);
    }

    private void apply_clearing() {
        if (search_stored.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
            setAdapter(current_selection, true);
        }
    }

    private void init_listeners() {
        apply_clearing();
        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_stored.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });


        search_stored.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
                if (current_selection == null || current_selection.length == 0){
                    return;
                }
                ArrayList<File> refined = new ArrayList<>();
                String entered = search_stored.getText().toString();
                if (entered == null || entered.length() == 0){
                    setAdapter(current_selection, true);
                    return;
                }

                for (File entry: current_selection){
                    String name = entry.getName();
                    if (name.toLowerCase().contains(entered.toLowerCase())){
                        refined.add(entry);
                    }
                }
                File[] files = new File[refined.size()];
                for (int i = 0; i < refined.size(); i++){
                    files[i] = refined.get(i);
                }
                setAdapter(files, true);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        close_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        path_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (counter == 0){
                    return;
                }
                onBackPressed();
            }
        });
    }

    private static int counter = 0;
    @Override
    public void onBackPressed() {
        if (exp_open){
            close_search_exp();
            return;
        }
        try {
            if (counter == 0) {
                current_path = null;
                super.onBackPressed();
                return;
            }
            if (counter == 1) {
                counter = 0;
                init_storage();
                if (inited_paths != null && inited_paths.length > 0) {
                    deprint_info();
                    setAdapter(inited_paths, false);
                } else {
                    Toast.makeText(this, "File error.", Toast.LENGTH_SHORT).show();
                    onBackPressed();
                }
                return;
            }
            counter -= 1;
            File parent_path = new File(current_path).getParentFile();
            current_path = parent_path.getAbsolutePath();
            print_info();
            File[] media = parent_path.listFiles();
            if (EXPLORER_OPTION == EXPLORER_DIR) {
                ArrayList<File> dirs = new ArrayList<>();
                for (File entry : media) {
                    if (entry.isDirectory()) {
                        dirs.add(entry);
                    }
                }
                File[] media_dir = new File[dirs.size()];
                for (int i = 0; i < dirs.size(); i++) {
                    media_dir[i] = dirs.get(i);
                }
                media = media_dir;
            }

            setAdapter(media, true);
        }catch (Exception ignored){
            Toast.makeText(this, "Exception found.", Toast.LENGTH_SHORT).show();
            LOCAL_PROCESSED = true;
            QR_PROCESSED = false;
            k.DATA_FETCHED = null;
            finish();
        }
    }

    @Nullable
    public static String current_path = null;

    public void explorer_clear(View view) {
        search_stored.setText("");
        clear_text.setVisibility(View.GONE);
    }

    private void close_search_exp() {
        exp_open = false;
        search_bar.setVisibility(View.GONE);
        search_stored.setText("");
        Keyboard.hideSoft(aa.this, R.id.soira_explorer_layout, null);
    }

    private void open_search_exp() {
        exp_open = true;
        search_bar.setVisibility(View.VISIBLE);
        if (search_stored.isFocusable()){
            search_stored.requestFocus();
        }
        Keyboard.openSoft(aa.this, search_stored);

    }



    boolean exp_open = false;
    public void open_search_exp(View view) {
        open_search_exp();
    }

    public void close_back_search(View view) {
        close_search_exp();
    }
}
