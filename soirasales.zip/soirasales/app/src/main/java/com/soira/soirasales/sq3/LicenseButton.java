package com.soira.soirasales.sq3;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

public class LicenseButton extends Button{

    private void establishFont(){
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "geez.ttf"));
    }

    public LicenseButton(Context context) {
        super(context);
        establishFont();
    }

    public LicenseButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
    }

    public LicenseButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
    }

}
