package com.soira.soirasales.a10.s23;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.soira.soirasales.R;
import com.soira.soirasales.s24.OnConditionMet;
import com.soira.soirasales.sq3.SoiraTextView;

import java.util.ArrayList;


public class wql extends RecyclerView.Adapter<wql.ViewHolder> {

    private ArrayList<String> media_selected;

    private OnConditionMet ft4;

    private void fire_condition(String condition, int option){
        if (ft4 == null){
            return;
        }
        ft4.onConditionMet(condition, option);
    }

    private Context context;

    public wql(Context context, ArrayList<String> media_selected, OnConditionMet ft4) {
        this.context = context;
        this.media_selected = media_selected;
        this.ft4 = ft4;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        SoiraTextView device_name;
        ImageView delete_media;

        ViewHolder(@NonNull View v) {
            super(v);
            device_name = (SoiraTextView) v.findViewById(R.id.media_name);
            delete_media = (ImageView) v.findViewById(R.id.delete_media);

        }
        void setData(@NonNull final ArrayList<String> medias, final int position){
            final String value = medias.get(position);
            String[] content = value.split(":");
            final String user_name = content[0];
            final String user_id = content[1];

            device_name.setText(user_name);

            delete_media.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(value, 0); // so far, 0 is useless
                }
            });
        }
    }

    @NonNull
    @Override
    public wql.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.er, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(media_selected, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return media_selected.size();
    }

}