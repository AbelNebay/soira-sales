package com.soira.soirasales.a10.a66;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.soira.soirasales.R;
import com.soira.soirasales.s24.OnConditionMet;
import com.soira.soirasales.sq3.SoiraTextView;

import java.util.ArrayList;


public class qp extends RecyclerView.Adapter<qp.ViewHolder> {

    private ArrayList<String> media_stored;

    private OnConditionMet ft4;

    private void fire_condition(String condition, int option){
        if (ft4 == null){
            return;
        }
        ft4.onConditionMet(condition, option);
    }

    private Context context;

    public qp(Context context, ArrayList<String> media_stored, OnConditionMet ft4) {
        this.context = context;
        this.media_stored = media_stored;
        this.ft4 = ft4;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout stored_holder;
        SoiraTextView media_id, device_name, artist_name, media_title, media_price, copy_number;
        ImageView delete_media;

        ViewHolder(@NonNull View v) {
            super(v);
            stored_holder = (RelativeLayout) v.findViewById(R.id.stored_holder);
            artist_name = (SoiraTextView) v.findViewById(R.id.media_data);
            delete_media = (ImageView) v.findViewById(R.id.delete_media);

        }
        void setData(@NonNull final ArrayList<String> medias, final int position){
            final String value = medias.get(position);
            String[] content = value.split(":");

            final String id  = content[0]; // media_id
            final String device_label  = content[1]; // device_name
            final String artist  = content[2]; // artist_name
            final String title  = content[3]; // media_title
            final String price  = content[4]; // price
            final String copy  = content[5]; // copy_number

            artist_name.setText(artist + " - " + title);

            stored_holder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(value, 1);
                }
            });

            delete_media.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(value, 0);
                }
            });
        }
    }

    @NonNull
    @Override
    public qp.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.q, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(media_stored, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return media_stored.size();
    }

}