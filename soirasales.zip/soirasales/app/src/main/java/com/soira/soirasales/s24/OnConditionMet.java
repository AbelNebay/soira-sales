package com.soira.soirasales.s24;


public interface OnConditionMet {

    void onConditionMet(String id, int option);

}
