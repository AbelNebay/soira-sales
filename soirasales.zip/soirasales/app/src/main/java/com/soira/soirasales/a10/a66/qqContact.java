package com.soira.soirasales.a10.a66;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.soira.soirasales.R;
import com.soira.soirasales.s24.OnConditionMet;
import com.soira.soirasales.sq3.SoiraTextView;

import java.util.ArrayList;

import static com.aa.aaa.aaa.datamatrix.encoder.a.EXCESS;


public class qqContact extends RecyclerView.Adapter<qqContact.ViewHolder> {

    private ArrayList<String> media_stored;

    private OnConditionMet ft4;

    private void fire_condition(String condition, int option){
        if (ft4 == null){
            return;
        }
        ft4.onConditionMet(condition, option);
    }

    private Context context;

    public qqContact(Context context, ArrayList<String> media_stored, OnConditionMet ft4) {
        this.context = context;
        this.media_stored = media_stored;
        this.ft4 = ft4;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout stored_holder;
        SoiraTextView contact_name, contact_number;

        ViewHolder(@NonNull View v) {
            super(v);
            stored_holder = (RelativeLayout) v.findViewById(R.id.contact_holder);
            contact_name = (SoiraTextView) v.findViewById(R.id.contact_name);
            contact_number = (SoiraTextView) v.findViewById(R.id.contact_number);

        }
        void setData(@NonNull final ArrayList<String> medias, final int position){
            final String value = medias.get(position);
            String[] content = value.split(":");
            final String name  = content[0];
            final String number  = content[1];

            contact_name.setText(name);
            contact_number.setText(number);

            stored_holder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(number, 1);
                }
            });
        }
    }

    @NonNull
    @Override
    public qqContact.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.contact_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(media_stored, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return media_stored.size();
    }

}