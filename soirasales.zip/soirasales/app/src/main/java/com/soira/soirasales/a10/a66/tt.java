package com.soira.soirasales.a10.a66;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.soira.soirasales.R;
import com.soira.soirasales.s24.OnConditionMet;
import com.soira.soirasales.sq3.SoiraTextView;

import java.util.ArrayList;


public class tt extends RecyclerView.Adapter<tt.ViewHolder> {

    private ArrayList<String> media_stored;

    private OnConditionMet ft4;

    private void fire_condition(String condition, int option){
        if (ft4 == null){
            return;
        }
        ft4.onConditionMet(condition, option);
    }

    private Context context;

    public tt(Context context, ArrayList<String> media_stored, OnConditionMet ft4) {
        this.context = context;
        this.media_stored = media_stored;
        this.ft4 = ft4;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout stored_holder;
        SoiraTextView device_name, date_received;
        ImageView delete_media;

        ViewHolder(@NonNull View v) {
            super(v);
            stored_holder = (RelativeLayout) v.findViewById(R.id.stored_holder);
            device_name = (SoiraTextView) v.findViewById(R.id.media_id);
            date_received = (SoiraTextView) v.findViewById(R.id.date_received);
            delete_media = (ImageView) v.findViewById(R.id.delete_media);

        }
        void setData(@NonNull final ArrayList<String> medias, final int position){
            final String value = medias.get(position);
            String[] content = value.split(":");
            final String name  = content[1]; // device_id
            final String device_label  = content[2].split(",")[0]; // device_name
            final String sub_random = content[3];
            final String address = content[4];
            final String media_id  = content[5]; // media_id
            final String date  = content[6]; // date
            final String secs  = content[7]; // seconds captured as primary key


//        refined = qedf.xxss(refined);

            device_name.setText(device_label + " [" + address + "]");

            date_received.setText(date + ":" + secs);

            stored_holder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(value, 1);
                }
            });

            delete_media.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(value, 0);
                }
            });
        }
    }

    @NonNull
    @Override
    public tt.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.ww, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(media_stored, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return media_stored.size();
    }

}