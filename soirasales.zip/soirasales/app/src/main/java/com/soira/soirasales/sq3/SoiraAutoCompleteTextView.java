package com.soira.soirasales.sq3;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.AutoCompleteTextView;


public class SoiraAutoCompleteTextView extends AutoCompleteTextView{

    private void establishFont(){
        if (getTag() != null && getTag().equals("bold")){
            setTypeface(Typeface.createFromAsset(getContext().getAssets(), "menu_font.ttf"));
            return;
        }
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "soira_font.ttf"));
    }



    public SoiraAutoCompleteTextView(Context context) {
        super(context);
        establishFont();
    }

    public SoiraAutoCompleteTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
    }

    public SoiraAutoCompleteTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
    }

}
