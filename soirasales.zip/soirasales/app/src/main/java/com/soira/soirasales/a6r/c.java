package com.soira.soirasales.a6r;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.soira.soirasales.R;
import com.soira.soirasales.a10.a66.qp;
import com.aa.aaaa.aaa.oned.mn;
import com.soira.soirasales.s24.OnConditionMet;
import com.aa.aaaa.aaa.pdf417.decoder.ec.k;
import com.soira.soirasales.gf3.xxs;
import com.soira.soirasales.sq3.SoiraAutoCompleteTextView;
import com.soira.soirasales.sq3.SoiraButton;
import com.soira.soirasales.sq3.SoiraTextView;

import java.util.ArrayList;

public class c extends AppCompatActivity {
    RecyclerView stored_lister;
    SoiraAutoCompleteTextView search_stored;
    SoiraTextView warning;

    SoiraTextView media_id_text, media_id,
            artist_name_text, artist_name,
            media_title_text, media_title,
            media_price_text, media_price,
            remained_copy_text, remained_copy,
            alert_text;

    RelativeLayout outer_alert, inner_alert, bottomers, alert_message;
    ScrollView media_info_panel;
    SoiraButton finish_button, yes_button;
    ImageView clear_text;
    boolean opened = false, message_opened = false;
    @Nullable
    ArrayList<String> sales_medias;

    private void fetch_sales(){
        if (sales_medias != null){
            sales_medias.clear();
            sales_medias = null;
        }
        sales_medias = new ArrayList<>();
        Cursor cursor = new mn(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String media_id = cursor.getString(0);
                String device_name = cursor.getString(1);
                String artist_name = cursor.getString(2);
                String media_title = cursor.getString(3);
                String media_price = cursor.getString(4);
                String copy_number = cursor.getString(5);


                String combined = media_id + ":" + device_name + ":" + artist_name + ":" + media_title + ":" + media_price + ":" + copy_number;

                sales_medias.add(combined);
            }while (cursor.moveToPrevious());
            cursor.close();
        }
        if (sales_medias.size() == 0){
            search_stored.setEnabled(false);
            warning.setText("No media stored");
            warning.setVisibility(View.VISIBLE);
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
        }else {
            search_stored.setEnabled(true);
            warning.setVisibility(View.GONE);
            warning.setText("");
            set_whole();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.v);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#111111"));
            getWindow().setStatusBarColor(Color.parseColor("#111111"));
        }

        init_views();
        init_listeners();

        fetch_sales();

    }

    private void setClosed(){
        SELECTED = null;
        inner_alert.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                deprint_information();
                alert_message.setVisibility(View.GONE);
                outer_alert.setVisibility(View.GONE);
                opened = false;
                message_opened = false;
            }
        });
        bottomers.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.GONE);
            }
        });
    }


    private void open_alert(String message){
        alert_text.setText(message);
        alert_message.setVisibility(View.VISIBLE);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);
        outer_alert.setVisibility(View.VISIBLE);

        setInnerLayout(xxs.convert(this, 100));

        finish_button.setText("NO");
        yes_button.setText("YES");
        if (SELECTED == null){
            finish_button.setText("DONE");
            yes_button.setVisibility(View.GONE);
        }else {
            yes_button.setVisibility(View.VISIBLE);
        }
        bottomers.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = true;
            }
        });
    }

    private void setOpened(@NonNull String code_value){
        yes_button.setVisibility(View.GONE);
        print_information(code_value);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);

        setInnerLayout(xxs.convert(this, 260));

        outer_alert.setVisibility(View.VISIBLE);

        finish_button.setText("CLOSE");
        bottomers.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = false;
            }
        });
    }

    private void setInnerLayout(int height) {
        ViewGroup.LayoutParams layoutParams = inner_alert.getLayoutParams();
        layoutParams.height = height;
        inner_alert.setLayoutParams(layoutParams);
    }

    private void deprint_information(){
        media_info_panel.setVisibility(View.GONE);
        media_id.setText("");

        artist_name.setText("");
        media_title.setText("");
        media_price.setText("");
        remained_copy.setText("");
    }


    private void print_information(@NonNull String received) {
        media_info_panel.setVisibility(View.VISIBLE);
        if (received.contains(":")){
            String[] content = received.split(":");
            String id = content[0];
            String name = content[1]; // not necessary

            String artist = content[2];
            String title = content[3];
            String price = content[4];
            String copy = content[5];

            media_id.setText(" :  " + id);
            artist_name.setText(" :  " + artist);
            media_title.setText(" :  " + title);
            media_price.setText(" :  " + price + " Nakfa");
            remained_copy.setText(" :  " + k.reformat_copy(copy) + " copies");

        }else {
            Toast.makeText(this, "Error printing the information.", Toast.LENGTH_LONG).show();
        }
    }

    private void init_views() {
        stored_lister = (RecyclerView) findViewById(R.id.stored_medias);
        search_stored = (SoiraAutoCompleteTextView) findViewById(R.id.search_stored);
        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        media_info_panel = (ScrollView) findViewById(R.id.media_info_panel);
        bottomers = (RelativeLayout) findViewById(R.id.bottomers);
        alert_message = (RelativeLayout) findViewById(R.id.confirm_alert);

        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        finish_button = (SoiraButton) findViewById(R.id.finish_button);
        yes_button = (SoiraButton) findViewById(R.id.qr_button);
        warning = (SoiraTextView) findViewById(R.id.warning);

        media_id = (SoiraTextView) findViewById(R.id.media_id);
        media_id_text = (SoiraTextView) findViewById(R.id.media_id_text);

        artist_name = (SoiraTextView) findViewById(R.id.artist_name);
        artist_name_text = (SoiraTextView) findViewById(R.id.artist_name_text);

        media_title = (SoiraTextView) findViewById(R.id.media_title);
        media_title_text = (SoiraTextView) findViewById(R.id.media_title_text);

        media_price = (SoiraTextView) findViewById(R.id.media_price);
        media_price_text = (SoiraTextView) findViewById(R.id.media_price_text);

        remained_copy = (SoiraTextView) findViewById(R.id.remained_copies);
        remained_copy_text = (SoiraTextView) findViewById(R.id.remained_copies_text);

        alert_text = (SoiraTextView) findViewById(R.id.alert_text);

        clear_text = (ImageView) findViewById(R.id.store_clear_text);
    }

    private void apply_clearing() {
        if (search_stored.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
        }
    }

    private void init_listeners() {
        apply_clearing();
        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_stored.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });
        search_stored.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
                if (sales_medias.size() == 0){
                    return;
                }
                String entered = search_stored.getText().toString();
                if (entered != null && entered.length() > 2){
                    ArrayList<String> found = new ArrayList<>();
                    for (int i = 0; i < sales_medias.size(); i++){
                        String current = sales_medias.get(i);
                        if (current.toLowerCase().contains(entered.toLowerCase())){
                            found.add(current);
                        }
                    }
                    if (found.size() == 0){
                        warning.setText("No stored medias matches your search");
                        warning.setVisibility(View.VISIBLE);
                        set_stored_lists(null);
                    }else {
                        warning.setVisibility(View.GONE);
                        warning.setText("");
                        set_stored_lists(found);
                    }
                }else {
                    set_whole();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

        yes_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (message_opened){
                    if (SELECTED != null) {
                        delete_store(SELECTED);
                    }else {
                        setClosed();
                    }
                }
            }
        });
    }

    private void set_whole() {
        warning.setVisibility(View.GONE);
        warning.setText("");
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: sales_medias){
            secondary.add(entry);
        }
        set_stored_lists(secondary);
    }

    @Nullable
    qp qp;
    private void set_stored_lists(@Nullable ArrayList<String> entered) {
        if (entered == null || entered.size() == 0){
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
            return;
        }

        stored_lister.setLayoutManager(new LinearLayoutManager(this));
        qp = new qp(c.this, entered, new OnConditionMet() {
            @Override
            public void onConditionMet(@NonNull String id, int option) {
                switch (option){
                    case 1: // Holder is clicked
                        setOpened(id);
                        break;
                    case 0:
//                         delete clicked
                        Toast.makeText(c.this, "Not possible.", Toast.LENGTH_LONG).show();
//                        SELECTED = id;
//                        open_alert("Are you sure to delete?");

                }
            }
        });
        stored_lister.setAdapter(qp);
    }

    @Nullable
    String SELECTED = null;
    private void delete_store(@NonNull String refined) {
        String id = refined.split(":")[0];
        boolean sale_deleted;

        mn saleStored = new mn(this);
        sale_deleted = saleStored.deleteData(id);
        if (!sale_deleted){
            open_alert("Failed to deleted sales copies.");
            return;
        }
        SELECTED = null;
        fetch_sales();
        open_alert("Successfully deleted.");
    }
    @Override
    public void onBackPressed() {
        if (opened){
            setClosed();
            return;
        }
        super.onBackPressed();
    }
}
