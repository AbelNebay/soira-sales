package com.soira.soirasales.gf3;


import android.content.Context;
import android.support.annotation.NonNull;
import android.util.TypedValue;

public class xxs {

    public static int convert(@NonNull Context context, float value){
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }
}
