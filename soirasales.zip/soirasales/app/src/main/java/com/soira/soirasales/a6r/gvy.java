package com.soira.soirasales.a6r;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.soira.soirasales.R;
import com.soira.soirasales.a10.a66.qq;
import com.aaa.mp;
import com.soira.soirasales.s24.OnConditionMet;
import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.qedf;
import com.aa.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.aa;
import com.aa.aaaa.aaa.pdf417.decoder.ec.k;
import com.soira.soirasales.gf3.xxs;
import com.soira.soirasales.gf3.xxe;
import com.soira.soirasales.sq3.SoiraAutoCompleteTextView;
import com.soira.soirasales.sq3.SoiraButton;
import com.soira.soirasales.sq3.SoiraTextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class gvy extends AppCompatActivity {
    RecyclerView stored_lister;
    SoiraAutoCompleteTextView search_stored;
    SoiraTextView warning, message_template;

    SoiraTextView
            media_id_text, media_id,
            device_name_text, device_name,
            artist_name_text, artist_name,
            media_title_text, media_title,
            media_price_text, media_price,
            copy_granted_text, copy_granted,
            date_granted_text, date_granted,
            alert_text;

    RelativeLayout outer_alert, inner_alert, outer_dialog, inner_dialog, qr_holder, bottomers, alert_message;
    ScrollView media_info_panel;
    SoiraButton finish_button, qr_button, ok_button, no_button;
    ImageView clear_text, qr_place;
    boolean opened = false, message_opened = false;
    @Nullable
    ArrayList<String> stored_medias;

    private void fetch_stored(){
        if (stored_medias != null){
            stored_medias.clear();
            stored_medias = null;
        }
        stored_medias = new ArrayList<>();
        Cursor cursor = new mp(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String prefix = cursor.getString(0);
                String device_id = cursor.getString(1);
                String device_name = cursor.getString(2);
                String media_id = cursor.getString(3);
                String date = cursor.getString(4);
                String media_ran = cursor.getString(5);

                String combined = prefix + ":" + device_id + ":" + device_name + ":" + media_id + ":" + date + ":" + media_ran;

                stored_medias.add(combined);
            }while (cursor.moveToPrevious());
            cursor.close();
        }
        if (stored_medias.size() == 0){
            search_stored.setEnabled(false);
            warning.setText("No media stored");
            warning.setVisibility(View.VISIBLE);
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
        }else {
            search_stored.setEnabled(true);
            warning.setVisibility(View.GONE);
            warning.setText("");
            set_whole();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nkdc);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#111111"));
            getWindow().setStatusBarColor(Color.parseColor("#111111"));
        }

        init_views();
        init_listeners();

        fetch_stored();

    }

    private void setClosed(){
        create_qr(null);
        SELECTED = null;
        inner_alert.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                deprint_information();
                alert_message.setVisibility(View.GONE);
                outer_alert.setVisibility(View.GONE);
                opened = false;
                message_opened = false;
            }
        });
        bottomers.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.GONE);
            }
        });
    }


    private void open_alert(String message){
        alert_text.setText(message);
        alert_message.setVisibility(View.VISIBLE);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);
        outer_alert.setVisibility(View.VISIBLE);

        setInnerLayout(xxs.convert(this, 100));

        finish_button.setText("NO");
        qr_button.setText("YES");
        if (SELECTED == null){
            finish_button.setText("DONE");
            qr_button.setVisibility(View.GONE);
        }else {
            qr_button.setVisibility(View.VISIBLE);
        }
        bottomers.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = true;
            }
        });
    }

    private void setOpened(@NonNull String code_value){
        qr_button.setVisibility(View.VISIBLE);
        print_information(code_value);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);

        setInnerLayout(xxs.convert(this, 300));

        outer_alert.setVisibility(View.VISIBLE);
        String[] then = code_value.split(":");
        if (then.length == 6){
            code_value = then[0] + ":" + then[1] + ":" + then[2] + ":" + then[5] + ":" + then[3];
        }
        create_qr(code_value);

        finish_button.setText("CLOSE");
        qr_button.setText("OPEN QR");
        bottomers.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = false;
            }
        });
    }

    private void setInnerLayout(int height) {
        ViewGroup.LayoutParams layoutParams = inner_alert.getLayoutParams();
        layoutParams.height = height;
        inner_alert.setLayoutParams(layoutParams);
    }

    private void deprint_information(){
        media_info_panel.setVisibility(View.GONE);
        media_id.setText("");
        device_name.setText("");
        date_granted.setText("");

        artist_name.setText("");
        media_title.setText("");
        media_price.setText("");
        copy_granted.setText("");
    }

    @Nullable
    private String PRODUCTION_CONTENT = null;
    private void create_qr(String code_value) {
        PRODUCTION_CONTENT = code_value;
        qr_holder.setVisibility(View.GONE);
        qr_open = false;
        qr_button.setText("OPEN QR");
        qr_place.setImageBitmap(xxe.generate(this, qedf.xxss(code_value)));
    }

    private void print_information(@NonNull String received) {
        media_info_panel.setVisibility(View.VISIBLE);
        String[] big_content = received.split(":");
        String[] media_content;
        if (received.contains("%")){
            // Shared
            media_content = big_content[3].split("%");
            String id = big_content[1];
            String name = big_content[2].split(",")[0];
            String date;
            try {
                date = big_content[4] + ":" + big_content[5];
            }catch (Exception ignored){
                date = big_content[4];
            }

            String m_id = media_content[0];
//            if (m_id.startsWith("x")){
//                m_id = m_id.substring(1);
//            }
            String artist = media_content[1];
            String title = media_content[2];
            String price = media_content[3];
            String copy = media_content[4];


            media_id.setText(" :  " + m_id);
            device_name.setText(" :  " + name);
            date_granted.setText(" :  " + date);

            artist_name.setText(" :  " + artist);
            artist_name_text.setVisibility(View.VISIBLE);
            artist_name.setVisibility(View.VISIBLE);

            media_title.setText(" :  " + title);
            media_title_text.setVisibility(View.VISIBLE);
            media_title.setVisibility(View.VISIBLE);
            media_price.setText(" :  " + price + " Nakfa");
            media_price_text.setVisibility(View.VISIBLE);
            media_price.setVisibility(View.VISIBLE);

            copy_granted.setText(" :  " + k.reformat_copy(copy) + " copies");
        }else {
            // Sent
            media_content = big_content[3].split("#");
            int len = media_content.length;
            String ids = len > 0 ? media_content[0] : "Empty";
            if (len > 0) {
                ids = "";
                for (String entry : media_content) {
//                    if (entry.startsWith("x")){
//                        entry = entry.substring(1);
//                    }
                    ids += entry + " • ";
                }
                ids = ids.substring(0, ids.length() - 3);

            }

            String name = big_content[2].split(",")[0];
            String date;
            try {
                date = big_content[4] + ":" + big_content[5];
            }catch (Exception ignored){
                date = big_content[4];
            }


            media_id.setText(" :  " + ids);
            device_name.setText(" :  " + name);
            date_granted.setText(" :  " + date);

            artist_name.setText("");
            artist_name_text.setVisibility(View.GONE);
            artist_name.setVisibility(View.GONE);

            media_title.setText("");
            media_title_text.setVisibility(View.GONE);
            media_title.setVisibility(View.GONE);

            media_price.setText("");
            media_price_text.setVisibility(View.GONE);
            media_price.setVisibility(View.GONE);

            copy_granted.setText(" :  " + k.reformat_copy(String.valueOf(len)) + " medias");
        }

    }

    private void init_views() {
        stored_lister = (RecyclerView) findViewById(R.id.stored_medias);
        search_stored = (SoiraAutoCompleteTextView) findViewById(R.id.search_stored);
        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        outer_dialog = (RelativeLayout) findViewById(R.id.outer_dialog);
        media_info_panel = (ScrollView) findViewById(R.id.media_info_panel);
        qr_holder = (RelativeLayout) findViewById(R.id.qr_holder);
        bottomers = (RelativeLayout) findViewById(R.id.bottomers);
        alert_message = (RelativeLayout) findViewById(R.id.confirm_alert);

        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        inner_dialog = (RelativeLayout) findViewById(R.id.inner_dialog);
        finish_button = (SoiraButton) findViewById(R.id.finish_button);
        qr_button = (SoiraButton) findViewById(R.id.qr_button);
        ok_button = (SoiraButton) findViewById(R.id.ok_button);
        no_button = (SoiraButton) findViewById(R.id.no_button);
        warning = (SoiraTextView) findViewById(R.id.warning);
        message_template = (SoiraTextView) findViewById(R.id.message_template);

        media_id = (SoiraTextView) findViewById(R.id.media_id);
        media_id_text = (SoiraTextView) findViewById(R.id.media_id_text);

        device_name = (SoiraTextView) findViewById(R.id.device_name);
        device_name_text = (SoiraTextView) findViewById(R.id.device_name_text);

        artist_name = (SoiraTextView) findViewById(R.id.artist_name);
        artist_name_text = (SoiraTextView) findViewById(R.id.artist_name_text);

        media_title = (SoiraTextView) findViewById(R.id.media_title);
        media_title_text = (SoiraTextView) findViewById(R.id.media_title_text);

        media_price = (SoiraTextView) findViewById(R.id.media_price);
        media_price_text = (SoiraTextView) findViewById(R.id.media_price_text);

        copy_granted = (SoiraTextView) findViewById(R.id.copy_granted);
        copy_granted_text = (SoiraTextView) findViewById(R.id.copy_granted_text);

        date_granted = (SoiraTextView) findViewById(R.id.date_granted);
        date_granted_text = (SoiraTextView) findViewById(R.id.date_granted_text);

        alert_text = (SoiraTextView) findViewById(R.id.alert_text);

        clear_text = (ImageView) findViewById(R.id.store_clear_text);
        qr_place = (ImageView) findViewById(R.id.qr_place);
    }

    private void apply_clearing() {
        if (search_stored.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
        }
    }

    private void init_listeners() {
        apply_clearing();
        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_stored.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });
        search_stored.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
                if (stored_medias.size() == 0){
                    return;
                }
                String entered = search_stored.getText().toString();
                if (entered != null && entered.length() > 2){
                    ArrayList<String> found = new ArrayList<>();
                    for (int i = 0; i < stored_medias.size(); i++){
                        String current = stored_medias.get(i);
                        if (current.toLowerCase().contains(entered.toLowerCase())){
                            found.add(current);
                        }
                    }
                    if (found.size() == 0){
                        warning.setText("No stored medias matches your search");
                        warning.setVisibility(View.VISIBLE);
                        set_stored_lists(null);
                    }else {
                        warning.setVisibility(View.GONE);
                        warning.setText("");
                        set_stored_lists(found);
                    }
                }else {
                    set_whole();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        outer_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
                onBackPressed();
            }
        });
        inner_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

        qr_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (message_opened){
                    if (SELECTED != null) {
                        delete_store(SELECTED);
                    }else {
                        setClosed();
                    }
                    return;
                }
                if (qr_open) {
                    close_qr();
                }else {
                    open_qr();
                }
            }
        });

        no_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (production || production_failed){
                    close_dialog();
                    return;
                }
                to_sales();
            }
        });

        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (production){
                    share(Uri.parse(aa.dec("0tupsbhf0fnvmbufe010TPJSB`QSPEVDUJPO0") + production_file_name));
                }else if (production_failed){
                    production_failed = false;
                    close_dialog();
                    use_selector();
                    return;
                }
                close_dialog();
            }
        });

    }

    private void to_sales() {
        Intent sales = new Intent(gvy.this, c.class);
        startActivity(sales);
    }

    private void share(Uri text_uri){
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_STREAM, text_uri);
        shareIntent.setType("text/plain");
        startActivity(Intent.createChooser(shareIntent, "Sending file"));
    }

    private void close_qr() {
        qr_holder.setVisibility(View.GONE);
        qr_open = false;
        qr_button.setText("OPEN QR");
    }

    private void open_qr() {
        qr_holder.setVisibility(View.VISIBLE);
        qr_open = true;
        qr_button.setText("CLOSE QR");
    }

    boolean qr_open = false;
    private void set_whole() {
        warning.setVisibility(View.GONE);
        warning.setText("");
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: stored_medias){
            secondary.add(entry);
        }
        set_stored_lists(secondary);
    }

    @Nullable
    qq qq;
    private void set_stored_lists(@Nullable ArrayList<String> entered) {
        if (entered == null || entered.size() == 0){
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
            return;
        }

        stored_lister.setLayoutManager(new LinearLayoutManager(this));
        qq = new qq(gvy.this, entered, new OnConditionMet() {
            @Override
            public void onConditionMet(@NonNull String id, int option) {
                switch (option){
                    case 1: // Holder is clicked
                        setOpened(id);
                        break;
                    case 0:
//                         delete clicked
                        SELECTED = id;
                        open_alert("Are you sure to delete?");

                }
            }
        });
        stored_lister.setAdapter(qq);
    }

    @Nullable
    String SELECTED = null;

    private void delete_store(@NonNull String refined) {
        mp mp = new mp(this);
        boolean deleted = mp.deleteData(refined.split(":")[5]);
        mp.close();
        SELECTED = null;
        if (deleted){
            fetch_stored();
            open_alert("Successfully deleted.");
        }else {
            open_alert("Failed to delete.");
        }
    }
    @Override
    public void onBackPressed() {
        if (dialog_opened){
            close_dialog();
            return;
        }
        if (qr_open){
            close_qr();
            return;
        }
        if (opened){
            setClosed();
            return;
        }
        super.onBackPressed();
    }

    public void onLocalButtonClicked(View view) {
        switch (view.getId()){
            case R.id.local_button:
                use_selector();
                break;
        }
    }

    private void close_dialog(){
        inner_dialog.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                outer_dialog.setVisibility(View.GONE);
                dialog_opened = false;
                message_template.setText("");
            }
        });
    }

    boolean dialog_opened = false;
    private void open_dialog(){
        inner_dialog.setScaleX(0);
        inner_dialog.setScaleY(0);
        outer_dialog.setVisibility(View.VISIBLE);

        inner_dialog.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                dialog_opened = true;
            }
        });
    }

    private void setSuccessDialog(String message) {
        if (production){
            ok_button.setText("YES");
            no_button.setText("NO");
        }
        open_dialog();
        message_template.setText(message);
    }

    private void setFailureDialog(String message) {
        open_dialog();
        message_template.setText(message);
    }

    private void use_selector() {
        boolean produced;
        try {
            produced = produce_file();
        } catch (IOException e) {
            e.printStackTrace();
            produced = false;
        }
        production = produced;
        if (produced){
            setSuccessDialog("File successfully saved. Do you want to share it?");
        }else {
            production_failed = true;
            ok_button.setText("TRY AGAIN");
            no_button.setText("USE QR");
            setFailureDialog("Production failed. Try again or use QR.");
        }
    }

    boolean production = false, production_failed = false;
    String production_file_name = aa.dec("TPJSB`GJMF/uyu");
    private boolean produce_file() throws IOException {
        if (PRODUCTION_CONTENT == null || PRODUCTION_CONTENT.equals("")){
            return false;
        }
        String path = aa.dec("tupsbhf0fnvmbufe010TPJSB`QSPEVDUJPO0");
        File file = new File(path);
        if (!file.exists()) {
            boolean made = file.mkdirs();
            if (!made) {
                Toast.makeText(this, "File production error.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        try {
            production_file_name = PRODUCTION_CONTENT.split(":")[2];
        }catch (Exception ignored){
            production_file_name = aa.dec("TPJSB`GJMF/uyu");
        }
        FileOutputStream fileOutputStream = new FileOutputStream(path + production_file_name);
        fileOutputStream.write(qedf.Wec.fs(PRODUCTION_CONTENT).getBytes());
        return true;
    }

    public void back_home_history(View view) {
        onBackPressed();
    }
}
