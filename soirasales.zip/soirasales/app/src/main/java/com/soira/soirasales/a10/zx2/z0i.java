package com.soira.soirasales.a10.zx2;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.soira.soirasales.R;
import com.soira.soirasales.s24.ft5;
import com.soira.soirasales.sq3.SoiraTextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import static com.soira.soirasales.a6r.aa.current_path;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_ADS;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_DIR;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_MAIN;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_OPTION;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_SOIRA;


public class z0i extends RecyclerView.Adapter<z0i.ViewHolder> {

    private ArrayList<File> path_lists;

    private ft5 ft5;

    private void fire_condition(File[] media){
        if (ft5 == null){
            return;
        }
        ft5.onExplorer(media);
    }

    private Context context;

    public z0i(Context context, ArrayList<File> path_lists, ft5 ft5) {
        this.context = context;
        this.path_lists = path_lists;
        this.ft5 = ft5;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout explorer_holder;
        SoiraTextView path_name;
        ImageView path_image;

        ViewHolder(@NonNull View v) {
            super(v);
            explorer_holder = (RelativeLayout) v.findViewById(R.id.explorer_holder);
            path_name = (SoiraTextView) v.findViewById(R.id.path_name);
            path_image = (ImageView) v.findViewById(R.id.path_image);

        }
        void setData(@NonNull final ArrayList<File> medias, final int position){
            final File value = medias.get(position);
            String label = value.getName();
            path_name.setText(label.equals("0") ? "Internal memory" : label);
            boolean found = false;
            if (value.isFile()){
                path_image.setImageResource(R.drawable.file);
                found = true;
            }else {
                path_image.setImageResource(R.drawable.folder);
            }
            final boolean isFound = found;
            explorer_holder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isFound){
                        if (EXPLORER_OPTION == EXPLORER_SOIRA) {
                            long size = 0L;
                            try {
                                FileInputStream fileInputStream = new FileInputStream(value);
                                size = fileInputStream.getChannel().size();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            if (size > 0 && size < 10 * 1024) {
                                ft5.onFound(value.getAbsolutePath());
                                return;
                            }
                            Toast.makeText(context, "File selected is too large.", Toast.LENGTH_SHORT).show();
                        }else if (EXPLORER_OPTION == EXPLORER_ADS || EXPLORER_OPTION == EXPLORER_MAIN){
                            ft5.onFound(value.getAbsolutePath());
                        }
                    }else {
                        if (value.isDirectory()){
                            File[] media = value.listFiles();
                            if (EXPLORER_OPTION == EXPLORER_DIR) {
                                ArrayList<File> dirs = new ArrayList<>();
                                for (File entry : media) {
                                    if (entry.isDirectory()){
                                        dirs.add(entry);
                                    }
                                }
                                File[] media_dir = new File[dirs.size()];
                                for (int i = 0; i < dirs.size(); i++){
                                    media_dir[i] = dirs.get(i);
                                }
                                media = media_dir;
                            }

                            current_path = value.getAbsolutePath();
                            fire_condition(media);
                        }else {
                            Toast.makeText(context, "File is invalid.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public z0i.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.gty, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(this.path_lists, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return this.path_lists.size();
    }

}