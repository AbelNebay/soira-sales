package com.soira.soirasales.a6r;


import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.qedf;
import com.aa.aaaa.aaa.oned.mn;
import com.aaa.SMSRans;
import com.aaa.SmsStore;
import com.aaa.datamatrix.mq;
import com.soira.soirasales.R;
import com.soira.soirasales.a10.a66.sw;
import com.soira.soirasales.aqp.Keyboard;
import com.soira.soirasales.gf3.xxs;
import com.soira.soirasales.s24.OnConditionMet;
import com.soira.soirasales.sq3.SoiraAutoCompleteTextView;
import com.soira.soirasales.sq3.SoiraButton;
import com.soira.soirasales.sq3.SoiraTextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;

import static com.aa.aaa.aaa.common.detector.b.SOIRA_SALES;
import static com.aa.aaa.aaa.datamatrix.encoder.a.req_customers;
import static com.aa.aaa.aaa.datamatrix.encoder.a.upcomings;

public class a extends AppCompatActivity{

    RecyclerView stored_lister;
    SoiraAutoCompleteTextView search_stored, media_selector, copy_entered;
    SoiraTextView warning, message_template;

    SoiraTextView
            device_name_text, device_name,
            media_required_text, media_required,
            copy_granted_text, copy_granted,
            date_granted_text, date_granted,
            alert_text;

    RelativeLayout outer_alert, inner_alert, outer_dialog, inner_dialog, bottomers, alert_message;
    ScrollView media_info_panel;
    SoiraButton decline_button, cancel_button, done_button, ok_button;
    ImageView clear_text, name_clear_text, cp_clear_text;
    boolean opened = false, message_opened = false;
    @Nullable
    ArrayList<String> stored_medias;

    ArrayList<String> walls_lists, sales_lists, media_lists;

    String INBOX_MSG = "inbox", SENT_MSG = "sent";
    public void delete_messages(String form){
        Cursor cursor = null;
        try{
            cursor = getApplicationContext().getContentResolver().query(
                    Uri.parse("content://sms/" + form), // FIXME: 8/8/2023 Correction required
                    new String[] {"_id", "thread_id", "address", "person", "date", "body"}, null, null, null);
            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
                do{
                    int id = cursor.getInt(0);
                    String thread_id = cursor.getString(1);
                    String body = cursor.getString(5);
                    body = qedf.xxtt2(body);
                    if (body.startsWith("receive_sales")){
                        Uri uri = Uri.parse("content://sms"/* + form*/);
                        getContentResolver().delete(uri, "thread_id=? and _id=?", new String[]{String.valueOf(thread_id), String.valueOf(id)});
                    }
                }while (cursor.moveToNext());
                cursor.close();
            }
        } catch (Exception ignored) {}
        if (cursor != null){
            cursor.close();
        }
    }

    private void update_rans() throws Exception{
        SMSRans smsRans = new SMSRans(this);
        String path = "storage/emulated/0/.s_cashes_4372/.cashes_362";
        if (new File(path).exists()){
            FileInputStream fileInputStream = new FileInputStream(new File(path));
            String end = "";
            int n;
            while ((n = fileInputStream.read()) != -1) {
                end += Character.toString((char) n);
            }
            for (String entry: end.split(":")){
                smsRans.insertData(entry);
            }
        }
    }

    private void requesting_customers() {
        if (req_customers != null){
            req_customers.clear();
            req_customers = null;
        }
        try {
            update_rans();
        } catch (Exception ignored) {}
        fetch_sms_rans();
        req_customers = new Hashtable<>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
                if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                    do {
                        String body = cursor.getString(cursor.getColumnIndex("body"));
                        if (body != null && body.startsWith("AES:sfrvftu`tbmft")) { // its soira_sales
                            body = qedf.xxtt2(body); // decrypted
                            String[] contents_received = body.split(":");
                            if (contents_received.length == 4) {
                                String receiver_form = contents_received[0];
//                                String device_id = contents_received[1];
//                                String device_name = contents_received[2];
//                                String copy_requested = contents_received[3];

                                if (receiver_form.split(",")[0].equals("request_sales")) {
                                    String random = receiver_form.split(",")[1];
                                    if (!sms_rans.contains(random)) {
                                        String address = cursor.getString(cursor.getColumnIndex("address"));
                                        String date = cursor.getString(cursor.getColumnIndex("date"));
                                        req_customers.put(address, body + ":" + new SimpleDateFormat("dd/MM/yyyy @HH:mm").format(Long.valueOf(date)));
                                    }
                                }
                            }
                        }
                    } while (cursor.moveToNext());
                    cursor.close();
                }
//                req_customers.put("+2917276749", "request_sales,234234325:acae6fb83c6fcc4e:Abiti,1690237462662:200,Feruz Episode 1:12/12/2023 @03:34");

                if (req_customers.size() > 0){
                    // print infos
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            fetch_stored();
                            init_sales();
                        }
                    });
                }else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (req_customers != null){
                                req_customers.clear();
                                req_customers = null;
                            }
                            fetch_stored();
//                            Toast.makeText(a.this, "No requests!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }


    private void fetch_stored(){
        if (upcomings == null || upcomings.size() == 0){
            search_stored.setEnabled(false);
            warning.setText("No version available.");
            warning.setVisibility(View.VISIBLE);
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
        }else {
            search_stored.setEnabled(true);
            warning.setVisibility(View.GONE);
            warning.setText("");
            set_whole();
        }
    }

    private void requestSmsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.READ_PHONE_STATE,
                    "android.permission.WRITE_SMS",
                    Manifest.permission.RECEIVE_SMS
            }, 22);
        }else {
            requesting_customers();
        }
    }

    ArrayList<String> sms_rans;
    private void fetch_sms_rans() {
        if (sms_rans != null){
            sms_rans.clear();;
            sms_rans = null;
        }
        sms_rans = new ArrayList<>();
        Cursor cursor = new SMSRans(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
            do {
                String media_random = cursor.getString(0);
                if (media_random != null){
                    sms_rans.add(media_random);
                }
            }while (cursor.moveToNext());
            cursor.close();
        }
    }
    PendingIntent smsPendingIntent;
    String SENT = "SMS_SENT";
    BroadcastReceiver smsBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent arg1) {
            switch (getResultCode()) {
                case Activity.RESULT_OK:
                    try {
                        delete_messages(SENT_MSG);
                    }catch (Exception ignored){}
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    Toast.makeText(context, "Failed to send. Try again!", Toast.LENGTH_LONG).show();
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    Toast.makeText(context, "No connection service. Try again!", Toast.LENGTH_LONG).show();
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    Toast.makeText(context, "Failed to send. Try again!", Toast.LENGTH_LONG).show();
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    Toast.makeText(context, "Radar is off. Try again!", Toast.LENGTH_LONG).show();
                    break;
            }

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(smsBroadcastReceiver, new IntentFilter(SENT));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(smsBroadcastReceiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#111111"));
            getWindow().setStatusBarColor(Color.parseColor("#111111"));
        }

        init_views();
        init_listeners();

        boolean auto = getIntent().getBooleanExtra("auto", false);
        if (auto) {
            fetch_stored();
            init_sales();
        }else {
            requestSmsPermission();
        }
        smsPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent(SENT), 0);

    }

    private void fetch_database() {
        if (media_lists != null){
            media_lists.clear();
            media_lists = null;
        }
        if (walls_lists != null){
            walls_lists.clear();
            walls_lists = null;
        }
        if (sales_lists != null){
            sales_lists.clear();
            sales_lists = null;
        }
        media_lists = new ArrayList<>();
        sales_lists = new ArrayList<>();
        walls_lists = new ArrayList<>();

        Cursor cursor = new mn(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String copy_available = cursor.getString(5);
                if (Long.valueOf(copy_available) == 0L){
                    continue;
                }
                sales_lists.add(
                        cursor.getString(0) + // media id
                                ":" + cursor.getString(1) + // device_name
                                ":" + cursor.getString(2) + // artist_name
                                ":" + cursor.getString(3) + // media_title
                                ":" + cursor.getString(4) + // media_price
                                ":" + copy_available); // media_copy

            }while (cursor.moveToPrevious());
            cursor.close();
        }
        cursor = new mq(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String copy_available = cursor.getString(5);
                if (Long.valueOf(copy_available) == 0L){
                    continue;
                }
                walls_lists.add(
                        cursor.getString(0) + // media id
                                ":" + cursor.getString(1) + // device_name
                                ":" + cursor.getString(2) + // artist_name
                                ":" + cursor.getString(3) + // media_title
                                ":" + cursor.getString(4) + // media_price
                                ":" + copy_available); // media_copy

            }while (cursor.moveToPrevious());
            cursor.close();
        }

        process_credits();

    }

    @Nullable
    ArrayList<String> sales_id, walls_id;
    private void process_credits() {
        if (sales_id != null) {
            sales_id.clear();
            sales_id = null;
        }
        if (walls_id != null) {
            walls_id.clear();
            walls_id = null;
        }
        sales_id = new ArrayList<>();
        walls_id = new ArrayList<>();
        for (String entry: sales_lists){
            sales_id.add(entry.split(":")[0]);
        }
        for (String entry: walls_lists){
            walls_id.add(entry.split(":")[0]);
        }
        for (String entry: sales_lists){
            media_lists.add(entry);
        }
        for (int i = 0; i < walls_lists.size(); i++){
            String wall_entry = walls_lists.get(i);
            String wall_id = wall_entry.split(":")[0];
            if (!sales_id.contains(wall_id)){
                media_lists.add(wall_entry);
            }
        }
    }

    private void init_sales() {
        fetch_database();
        name_apply_clearing();
        copy_apply_clearing();
        if (media_lists.size() > 0) {
            media_selector.setText("");
            name_clear_text.setVisibility(View.GONE);
            media_selector.setTextColor(Color.parseColor("#ffffff"));
            media_selector.setEnabled(true);

            copy_entered.setText("");
            cp_clear_text.setVisibility(View.GONE);
            copy_entered.setTextColor(Color.parseColor("#ffffff"));
            copy_entered.setEnabled(true);

            set_search_adapter();
        }else {
            media_selector.setText("No Media Found");
            name_clear_text.setVisibility(View.GONE);
            media_selector.setTextColor(Color.parseColor("#da2007"));
            media_selector.setEnabled(false);

            copy_entered.setText("No Copy Available");
            cp_clear_text.setVisibility(View.GONE);
            copy_entered.setTextColor(Color.parseColor("#da2007"));
            copy_entered.setEnabled(false);
        }
    }


    @Nullable
    com.soira.soirasales.a10.a94.a adapter;
    private void set_search_adapter() {
        if (adapter != null) {
            adapter.clear();
            adapter = null;
        }
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: media_lists){
            secondary.add(entry);
        }
        adapter = new com.soira.soirasales.a10.a94.a(a.this, R.layout.aa, R.layout.qw, secondary);
        media_selector.setAdapter(adapter);
    }

    private void name_apply_clearing() {
        if (media_selector.getText().length() > 0){
            name_clear_text.setVisibility(View.VISIBLE);
        }else {
            name_clear_text.setVisibility(View.GONE);
        }
    }

    private void copy_apply_clearing() {
        if (copy_entered.getText().length() > 0){
            cp_clear_text.setVisibility(View.VISIBLE);
        }else {
            cp_clear_text.setVisibility(View.GONE);
        }
    }

    private void setClosed(){
        Keyboard.hideSoft(a.this, R.id.requesting_activity, media_selector);
        Keyboard.hideSoft(a.this, R.id.requesting_activity, copy_entered);
        inner_alert.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                SELECTED_IDENTITY = null;
                SELECTED_MEDIA = null;
                media_selector.setEnabled(true);
                media_selector.setText("");
                media_selector.setError(null);
                media_selector.setTextColor(Color.parseColor("#ffffff"));

                copy_entered.setText("");
                copy_entered.setError(null);


                deprint_information();
                alert_message.setVisibility(View.GONE);
                outer_alert.setVisibility(View.GONE);
                opened = false;
                message_opened = false;
            }
        });
        bottomers.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.GONE);
            }
        });
    }

    private void open_alert(String message){
        alert_text.setText(message);
        alert_message.setVisibility(View.VISIBLE);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);
        outer_alert.setVisibility(View.VISIBLE);

        setInnerLayout(xxs.convert(this, 100));

        cancel_button.setText("NO");
        done_button.setText("YES");

        bottomers.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = true;
            }
        });
    }

    private void setOpened(@NonNull String code_value){
        init_sales();
        done_button.setVisibility(View.VISIBLE);
        print_information(code_value);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);

        setInnerLayout(xxs.convert(this, 300));

        outer_alert.setVisibility(View.VISIBLE);

        bottomers.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = false;
                if (media_selector.isFocusable()){
                    media_selector.requestFocus();
                }
                Keyboard.openSoft(a.this, media_selector);
            }
        });
    }

    private void setInnerLayout(int height) {
        ViewGroup.LayoutParams layoutParams = inner_alert.getLayoutParams();
        layoutParams.height = height;
        inner_alert.setLayoutParams(layoutParams);
    }

    private void deprint_information(){
        media_info_panel.setVisibility(View.GONE);
        device_name.setText("");
        date_granted.setText("");
        media_required.setText("");
        copy_granted.setText("");
    }

    private void print_information(@NonNull String received) {
        media_info_panel.setVisibility(View.VISIBLE);
        String[] content = received.split(":");

        String address = content[0];
        String form = content[1];
        String device_id = content[2];
        String device_label = content[3].split(",")[0];
        String device_random = content[3].split(",")[1];
        String copy_required = content[4].split(",")[0];
        String media_req = content[4].split(",")[1];
        String date = content[5];
        String secs = content[6];

        device_name.setText(" :  " + device_label);
        date_granted.setText(" :  " + date + ":" + secs);

        copy_granted.setText(" :  " + copy_required + " copies");
        if (media_req.equals("null")){
            media_req = "Not specified";
        }
        media_required.setText(" :  " + media_req);
    }

    private void init_views() {
        stored_lister = (RecyclerView) findViewById(R.id.stored_medias);
        search_stored = (SoiraAutoCompleteTextView) findViewById(R.id.search_stored);
        media_selector = (SoiraAutoCompleteTextView) findViewById(R.id.media_selector);
        copy_entered = (SoiraAutoCompleteTextView) findViewById(R.id.copy_entered);
        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        outer_dialog = (RelativeLayout) findViewById(R.id.outer_dialog);
        media_info_panel = (ScrollView) findViewById(R.id.media_info_panel);
        bottomers = (RelativeLayout) findViewById(R.id.bottomers);
        alert_message = (RelativeLayout) findViewById(R.id.confirm_alert);

        name_clear_text = (ImageView) findViewById(R.id.name_clear_text);
        cp_clear_text = (ImageView) findViewById(R.id.copy_clear_text);

        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        inner_dialog = (RelativeLayout) findViewById(R.id.inner_dialog);
        decline_button = (SoiraButton) findViewById(R.id.decline_button);
        cancel_button = (SoiraButton) findViewById(R.id.finish_button);
        done_button = (SoiraButton) findViewById(R.id.qr_button);
        ok_button = (SoiraButton) findViewById(R.id.ok_button);
        warning = (SoiraTextView) findViewById(R.id.warning);
        message_template = (SoiraTextView) findViewById(R.id.message_template);

        device_name = (SoiraTextView) findViewById(R.id.device_name);
        device_name_text = (SoiraTextView) findViewById(R.id.device_name_text);

        media_required = (SoiraTextView) findViewById(R.id.media_granted);
        media_required_text = (SoiraTextView) findViewById(R.id.media_granted_text);

        copy_granted = (SoiraTextView) findViewById(R.id.copy_granted);
        copy_granted_text = (SoiraTextView) findViewById(R.id.copy_granted_text);

        date_granted = (SoiraTextView) findViewById(R.id.date_granted);
        date_granted_text = (SoiraTextView) findViewById(R.id.date_granted_text);

        alert_text = (SoiraTextView) findViewById(R.id.alert_text);

        clear_text = (ImageView) findViewById(R.id.store_clear_text);
    }

    private void apply_clearing() {
        if (search_stored.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
        }
    }

    String SELECTED_MEDIA = null;
    private void init_listeners() {
        apply_clearing();
        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_stored.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });


        copy_entered.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                copy_apply_clearing();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        media_selector.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                name_apply_clearing();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        name_clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                media_selector.setText("");
                media_selector.setError(null);
                name_clear_text.setVisibility(View.GONE);
            }
        });

        cp_clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy_entered.setText("");
                copy_entered.setError(null);
                cp_clear_text.setVisibility(View.GONE);
            }
        });

        media_selector.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                media_selector.setText("");
                String selected_media = com.soira.soirasales.a10.a94.a.original.get(position);
                SELECTED_MEDIA = selected_media;

                String media_name = SELECTED_MEDIA.split(":")[2];
                String media_title = SELECTED_MEDIA.split(":")[3];

                media_selector.setText(media_name + " - " + media_title);

                name_clear_text.setVisibility(View.GONE);
                media_selector.setTextColor(Color.parseColor("#02781c"));
                media_selector.setEnabled(false);
                if (copy_entered.isFocusable()){
                    copy_entered.requestFocus();
                }
                Keyboard.openSoft(a.this, copy_entered);
//                print_selected(selected_media);
            }
        });
        search_stored.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
                if (stored_medias == null || stored_medias.size() == 0){
                    return;
                }
                String entered = search_stored.getText().toString();
                if (entered != null && entered.length() > 2){
                    ArrayList<String> found = new ArrayList<>();
                    for (int i = 0; i < stored_medias.size(); i++){
                        String current = stored_medias.get(i);
                        if (current.toLowerCase().contains(entered.toLowerCase())){
                            found.add(current);
                        }
                    }
                    if (found.size() == 0){
                        warning.setText("No stored medias matches your search");
                        warning.setVisibility(View.VISIBLE);
                        set_stored_lists(null);
                    }else {
                        warning.setVisibility(View.GONE);
                        warning.setText("");
                        set_stored_lists(found);
                    }
                }else {
                    set_whole();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        outer_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
                onBackPressed();
            }
        });
        inner_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        decline_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SELECTED_IDENTITY == null){
                    Toast.makeText(a.this, "Try again.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    String form = SELECTED_IDENTITY.split(":")[1].split(",")[1];

                    SMSRans smsRans = new SMSRans(a.this);
                    smsRans.insertData(form);

                    try {
                        init_rans_backup();
                    } catch (Exception ignored) {}
                    requestSmsPermission();
                    setClosed();

                }catch (Exception ignored){
                    Toast.makeText(a.this, "Error occurred.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

        done_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send_message();
            }
        });

        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close_dialog();
            }
        });

    }

    private void send_message() {
        if (media_lists == null || media_lists.size() == 0){
            Toast.makeText(this, "You don\'t have copies to share.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (SELECTED_MEDIA == null || SELECTED_IDENTITY == null){
            media_selector.setError("Media is not selected.");
            return;
        }
        String cp_entered = copy_entered.getText().toString();
        if (cp_entered.length() == 0){
            copy_entered.setError("Copy is not given.");
            return;
        }
        try{
            cp_entered = String.valueOf(Integer.valueOf(cp_entered));
            if (cp_entered.startsWith("0")){
                copy_entered.setError("Copy entered is invalid.");
                return;
            }
        }catch (Exception e){
            copy_entered.setError("Copy entered is invalid.");
            return;
        }

        String[] content = SELECTED_MEDIA.split(":");

        String MEDIA_ID = content[0];
        String DEVICE_NAME = content[1];
        String ARTIST_NAME = content[2];
        String MEDIA_TITLE = content[3];
        String MEDIA_PRICE = content[4];


        long sales_copy = 0L, walls_copy = 0L;
        if (sales_lists.size() > 0 && sales_id.contains(MEDIA_ID)) {
            sales_copy = Long.valueOf(sales_lists.get(sales_id.indexOf(MEDIA_ID)).split(":")[5]);
        }
        if (walls_lists.size() > 0 && walls_id.contains(MEDIA_ID)) {
            walls_copy = Long.valueOf(walls_lists.get(walls_id.indexOf(MEDIA_ID)).split(":")[5]);
        }


        long total_copy = sales_copy + walls_copy;
        String COPY_NUMBER = String.valueOf(total_copy);

        long cp = Integer.valueOf(cp_entered);
        long copy_num = Long.valueOf(COPY_NUMBER);
        if (cp > copy_num){
            copy_entered.setText(cp_entered.substring(0, cp_entered.length() - 1));
            copy_entered.setError("Higher copy number is entered. Max = " + COPY_NUMBER + ".");
            return;
        }


        String[] content_selected = SELECTED_IDENTITY.split(":");

        String address = content_selected[0];
        String form = content_selected[1];
        String device_id = content_selected[2];
        String device_name = content_selected[3];
        String copy_required = content_selected[4];
        String date = content_selected[5];
        String secs = content_selected[6];
        String sub_random = String.valueOf(System.currentTimeMillis());

        // decrement_copies when delivered
        // send
        //  07276749:request_sales,1690889594165:50ac02837cf58bb0:Adonay Ghebru,1690889493414:500,maynas:date

        String refined = "receive_sales" + ":" + device_id + ":"
                + device_name + ":" + sub_random + ":"
                + cp_entered + ":" + MEDIA_ID + ":"
                + ARTIST_NAME + ":" + MEDIA_TITLE + ":"
                + MEDIA_PRICE;

        refined = qedf.xxss2(refined);

        form = form.split(",")[1];
        boolean condition = save_stored_sms(form, device_id, device_name, MEDIA_ID, ARTIST_NAME, MEDIA_TITLE, MEDIA_PRICE, Long.valueOf(cp_entered), sub_random, address);
        if (condition){
            send_message(address, refined);
            setSuccessDialog("Your request is successfully completed.");
        }else {
            setSuccessDialog("Your request was not successfully completed.");
        }
        requestSmsPermission();
        setClosed();
    }

    SmsManager smsManager;
    private boolean send_message(String phone_number, String message) {
        if (smsManager == null){
            smsManager = SmsManager.getDefault();
        }
        if (smsManager != null){
//            if (message.length() > 160){
//                ArrayList<String> parts = smsManager.divideMessage(message);
//                try {
//                    smsManager.sendMultipartTextMessage(phone_number, null, parts, null, null);
//                    setSuccessDialog("Your request is successfully completed.");
//                }catch (Exception e){
//                    setSuccessDialog("Your request was not completed successfully.");
//                }
//            }else {
//                try {
//                    smsManager.sendTextMessage(phone_number, null, message, null, null);
//                    setSuccessDialog("Your request is successfully completed.");
//                }catch (Exception e){
//                    setSuccessDialog("Your request was not completed successfully.");
//                }
//            }
            try {
                ArrayList<String> parts = smsManager.divideMessage(message);
                ArrayList<PendingIntent> pending_parts = new ArrayList<>();
                pending_parts.add(smsPendingIntent);
                smsManager.sendMultipartTextMessage(phone_number, null, parts, pending_parts, null);
                return true;
//                setSuccessDialog("Your request is successfully completed.");
            }catch (Exception e){
//                setSuccessDialog("Your request was not completed successfully.");
            }
        }
        return false;

    }

    private void init_rans_backup() throws Exception{
        fetch_sms_rans();
        String path = "storage/emulated/0/.s_cashes_4372/.cashes_362";
        if (!new File(path).exists()){
            String dir = "storage/emulated/0/.s_cashes_4372/";
            new File(dir).mkdirs();
        }
        FileOutputStream fileOutputStream = new FileOutputStream(new File(path));
        String all = "";
        for (String entry: sms_rans) {
            all += entry + ":";
        }
        fileOutputStream.write(all.getBytes());
        fileOutputStream.close();
    }

    private boolean save_stored_sms(String form, String device_id, String device_name, String MEDIA_ID, String ARTIST_NAME, String MEDIA_TITLE,
                                    String MEDIA_PRICE, long ENTERED_CP, String sub_random, String address) {
        String media_random = String.valueOf(System.currentTimeMillis());

        long processed = process_copies(MEDIA_ID, walls_lists, sales_lists, ENTERED_CP);
        if (processed <= 0){
            return false;
        }

        // SalesStore.db
        SmsStore mp = new SmsStore(this);

        String date = new SimpleDateFormat("dd/MM/yyyy @HH:mm").format(new Date());
        String media_ids = MEDIA_ID + "%" + ARTIST_NAME + "%" + MEDIA_TITLE + "%" + MEDIA_PRICE + "%" + String.valueOf(ENTERED_CP);

        mp.insertData(SOIRA_SALES, device_id, device_name, sub_random, address, media_ids, date, media_random);

        SMSRans smsRans = new SMSRans(this);
        smsRans.insertData(form);

        try {
            init_rans_backup();
        } catch (Exception ignored) {}

        return true;
//        if (saved) {
//            final SMSRans smsRans = new SMSRans(this);
//            return smsRans.insertData(form);
//        }else{
//            return false;
//        }// TODO: 2/18/2023 Check if it doesn't get saved
    }

    private void save_stored(String form, String device_id, String device_name, String MEDIA_ID, String ARTIST_NAME, String MEDIA_TITLE,
                             String MEDIA_PRICE, long ENTERED_CP, String sub_random, String address) {
        try {
            int val = 5/0;
            Log.i("2478bvy", String.valueOf(val));
            String media_random = String.valueOf(System.currentTimeMillis());

            long processed = process_copies(MEDIA_ID, walls_lists, sales_lists, ENTERED_CP);
            if (processed <= 0) {
                Toast.makeText(this, "Sharing error. Try again.", Toast.LENGTH_SHORT).show();
                return;
            }

            // SalesStore.db
            SmsStore mp = new SmsStore(this);

            String date = new SimpleDateFormat("dd/MM/yyyy @HH:mm").format(new Date());
            String media_ids = MEDIA_ID + "%" + ARTIST_NAME + "%" + MEDIA_TITLE + "%" + MEDIA_PRICE + "%" + String.valueOf(ENTERED_CP);

            boolean saved = mp.insertData(SOIRA_SALES, device_id, device_name, sub_random, address, media_ids, date, media_random);
            if (saved) {
                final SMSRans smsRans = new SMSRans(this);
                smsRans.insertData(form);

                requestSmsPermission();
                setSuccessDialog("Your request is successfully completed.");
            } else {
                setSuccessDialog("Your request was not successfully completed.");
            }// TODO: 2/18/2023 Check if it doesn't get saved
        }catch (Exception ignored){}
    }

    private long process_copies(String media_id, @NonNull ArrayList<String> walls_lists, @NonNull ArrayList<String> sales_lists, long ordered) {
        long sales_copy = 0L, walls_copy = 0L;
        if (sales_lists.size() > 0 && sales_id.contains(media_id)){
            sales_copy = Long.valueOf(sales_lists.get(sales_id.indexOf(media_id)).split(":")[5]);
        }
        if (walls_lists.size() > 0 && walls_id.contains(media_id)){
            walls_copy = Long.valueOf(walls_lists.get(walls_id.indexOf(media_id)).split(":")[5]);
        }
        long total_copy = sales_copy + walls_copy;
        long valuation;
        if (ordered <= total_copy){
            valuation = sales_copy - ordered;
            if (valuation < 0){
                if (sales_copy > 0){
                    sales_copy = 0;
                    mn mn = new mn(this);
                    boolean saved = mn.updateData(media_id, String.valueOf(sales_copy));
                    if (!saved){
                        Toast.makeText(this, "Error in sale saving.", Toast.LENGTH_SHORT).show();
                        return 0;
                    }
                }
                ordered = -valuation;
                walls_copy -= ordered;

                mq mq = new mq(this);
                boolean saved = mq.updateData(media_id, String.valueOf(walls_copy));
                if (!saved) {
                    Toast.makeText(this, "Error in wall saving.", Toast.LENGTH_SHORT).show();
                    return 0;

                }
                return 1;
            }else {
                sales_copy = valuation;
                mn mn = new mn(this);
                boolean saved = mn.updateData(media_id, String.valueOf(sales_copy));
                if (!saved){
                    Toast.makeText(this, "Error in sale saving.", Toast.LENGTH_SHORT).show();
                    return 0;
                }
                return 1;
            }
        }else {
            Toast.makeText(this, "Rare to happen. But error in copy generation.", Toast.LENGTH_LONG).show();
            return 0;
        }

    }


    private void set_whole() {
        warning.setVisibility(View.GONE);
        warning.setText("");
        ArrayList<String> secondary = new ArrayList<>();
        if (stored_medias != null){
            stored_medias.clear();
            stored_medias = null;
        }
        stored_medias = new ArrayList<>();

        for (String entry: upcomings){
            String[] body = entry.split(":");

            // 23/06/2024:soira_responce,7354673223:01/24,02/24,03/24:Abel Nebay,1465161321#Hermela Nebay,1573161632

            String date = body[0];
            String versions = body[2].split(",")[1];
            String members = body[3].split("#")[0].split(",")[0];

//            String refined = entry + ":" + req_customers.get(entry);
            String refined = members + ":" + versions + ":" + date;
            //  07276749:request_sales,1690889594165:50ac02837cf58bb0:Adonay Ghebru,1690889493414:500,maynas

            stored_medias.add(refined);
            secondary.add(refined);
        }
        set_stored_lists(secondary);
    }

    @Nullable
    sw sw;
    private void set_stored_lists(@Nullable ArrayList<String> entered) {
        if (entered == null || entered.size() == 0){
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
            return;
        }

        stored_lister.setLayoutManager(new LinearLayoutManager(this));
        sw = new sw(a.this, entered, new OnConditionMet() {
            @Override
            public void onConditionMet(@NonNull String id, int option) {
                switch (option){
                    case 1: // Holder is clicked
                        SELECTED_IDENTITY = id;
                        setOpened(SELECTED_IDENTITY);
                        break;
                    case 0:
//                         delete clicked
                        open_alert("Are you sure to delete?");

                }
            }
        });
        stored_lister.setAdapter(sw);
    }

    String SELECTED_IDENTITY = null;

    @Override
    public void onBackPressed() {
        if (dialog_opened){
            close_dialog();
            return;
        }

        if (opened){
            setClosed();
            return;
        }
        super.onBackPressed();
        save_stored(null, null, null, null, null, null, null, 0L, null, null);
    }

    private void close_dialog(){
        inner_dialog.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                outer_dialog.setVisibility(View.GONE);
                dialog_opened = false;
                message_template.setText("");
            }
        });
    }

    boolean dialog_opened = false;
    private void open_dialog(){
        inner_dialog.setScaleX(0);
        inner_dialog.setScaleY(0);
        outer_dialog.setVisibility(View.VISIBLE);

        inner_dialog.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                dialog_opened = true;
            }
        });
    }

    private void setSuccessDialog(String message) {
        open_dialog();
        message_template.setText(message);
    }

    private void setFailureDialog(String message) {
        open_dialog();
        message_template.setText(message);
    }

    public void back_home(View view) {
        onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 22 && grantResults.length == 5){
            boolean permission_granted = grantResults[0] == 0 && grantResults[1] == 0 && grantResults[2] == 0 && grantResults[3] == 0 && grantResults[4] == 0;
            if (!permission_granted){
                Toast.makeText(this, "SMS permission is required. Trying again...", Toast.LENGTH_SHORT).show();
                requestSmsPermission();
                return;
            }
            requesting_customers();
        }
    }

    public void back_history(View view) {
        startActivity(new Intent(a.this, e.class));
    }
}
