package com.soira.soirasales.sq3;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class SoiraTextView extends TextView{

    private void establishFont(){
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "soira_font.ttf"));
    }


    public SoiraTextView(Context context) {
        super(context);
        establishFont();
    }

    public SoiraTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
    }

    public SoiraTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
    }

}
