package com.soira.soirasales.a6r;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.aa.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.aa;
import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.qedf;
import com.aa.aaaa.aaa.oned.mn;
import com.aa.aaaa.aaa.pdf417.decoder.ec.k;
import com.aaa.datamatrix.mq;
import com.aaa.mp;
import com.soira.soirasales.R;
import com.soira.soirasales.a10.a94.a;
import com.soira.soirasales.gf3.xxe;
import com.soira.soirasales.sq3.SoiraAutoCompleteTextView;
import com.soira.soirasales.sq3.SoiraButton;
import com.soira.soirasales.sq3.SoiraTextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import er.leafpedia.dr34.qw;

import static com.aa.aaa.aaa.common.detector.b.SOIRA_SALES;
import static com.aa.aaa.aaa.datamatrix.encoder.a.EXCESS;
import static com.aa.aaa.aaa.datamatrix.encoder.a.RECEIVE;


public class gf extends AppCompatActivity{
    RelativeLayout calculated, outer_alert, inner_alert, outer_dialog, inner_dialog, share_holder;
    SoiraAutoCompleteTextView search_media, copy_number;
    ImageView name_clear_text, cp_clear_text, qr_place;

    SoiraTextView selected_media,
            media_id_text, media_id,
            artist_name_text, artist_name,
            title_name_text, title_name,
            price_text, price,
            available_copies_text, available_copies,
            direct_value, indirect_value, message_template;

    SoiraButton share_media, finish_button, ok_button, no_button;
    @Nullable
    ArrayList<String> walls_lists, sales_lists, media_lists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aa);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#111111"));
            getWindow().setStatusBarColor(Color.parseColor("#111111"));
        }

        init_views();
        init_listeners();
        init_sales();

    }

    private void fetch_database() {
        if (media_lists != null){
            media_lists.clear();
            media_lists = null;
        }
        if (walls_lists != null){
            walls_lists.clear();
            walls_lists = null;
        }
        if (sales_lists != null){
            sales_lists.clear();
            sales_lists = null;
        }
        media_lists = new ArrayList<>();
        sales_lists = new ArrayList<>();
        walls_lists = new ArrayList<>();

        Cursor cursor = new mn(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String copy_available = cursor.getString(5);
                if (Long.valueOf(copy_available) == 0L){
                    continue;
                }
                sales_lists.add(
                        cursor.getString(0) + // media id
                                ":" + cursor.getString(1) + // device_name
                                ":" + cursor.getString(2) + // artist_name
                                ":" + cursor.getString(3) + // media_title
                                ":" + cursor.getString(4) + // media_price
                                ":" + copy_available); // media_copy

            }while (cursor.moveToPrevious());
            cursor.close();
        }
        cursor = new mq(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String copy_available = cursor.getString(5);
                if (Long.valueOf(copy_available) == 0L){
                    continue;
                }
                walls_lists.add(
                        cursor.getString(0) + // media id
                                ":" + cursor.getString(1) + // device_name
                                ":" + cursor.getString(2) + // artist_name
                                ":" + cursor.getString(3) + // media_title
                                ":" + cursor.getString(4) + // media_price
                                ":" + copy_available); // media_copy

            }while (cursor.moveToPrevious());
            cursor.close();
        }

        process_credits();

    }

    @Nullable
    ArrayList<String> sales_id, walls_id;
    private void process_credits() {
        if (sales_id != null) {
            sales_id.clear();
            sales_id = null;
        }
        if (walls_id != null) {
            walls_id.clear();
            walls_id = null;
        }
        sales_id = new ArrayList<>();
        walls_id = new ArrayList<>();
        for (String entry: sales_lists){
            sales_id.add(entry.split(":")[0]);
        }
        for (String entry: walls_lists){
            walls_id.add(entry.split(":")[0]);
        }
        for (String entry: sales_lists){
            media_lists.add(entry);
        }
        for (int i = 0; i < walls_lists.size(); i++){
            String wall_entry = walls_lists.get(i);
            String wall_id = wall_entry.split(":")[0];
            if (!sales_id.contains(wall_id)){
                media_lists.add(wall_entry);
            }
        }
    }

    private void init_sales() {
        fetch_database();
        if (media_lists.size() > 0) {
            search_media.setEnabled(true);
            share_media.setEnabled(true);
            selected_media.setText("No media selected");
            set_search_adapter();
        }else {
            search_media.setEnabled(false);
            share_media.setEnabled(false);
            selected_media.setText("No media available for sharing");
            copy_number.setEnabled(false);
            copy_number.setText("");
        }
        name_apply_clearing();
        copy_apply_clearing();
    }


    @Nullable
    a adapter;
    private void set_search_adapter() {
        if (adapter != null) {
            adapter.clear();
            adapter = null;
        }
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: media_lists){
            secondary.add(entry);
        }
        adapter = new a(gf.this, R.layout.aa, R.layout.qw, secondary);
        search_media.setAdapter(adapter);
    }

    private void name_apply_clearing() {
        if (search_media.getText().length() > 0){
            name_clear_text.setVisibility(View.VISIBLE);
        }else {
            name_clear_text.setVisibility(View.GONE);
        }
    }

    private void copy_apply_clearing() {
        if (copy_number.getText().length() > 0){
            cp_clear_text.setVisibility(View.VISIBLE);
        }else {
            cp_clear_text.setVisibility(View.GONE);
        }
    }

    private void init_views() {
        calculated = (RelativeLayout) findViewById(R.id.calculated);
        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        outer_dialog = (RelativeLayout) findViewById(R.id.outer_dialog);
        inner_dialog = (RelativeLayout) findViewById(R.id.inner_dialog);
        share_holder = (RelativeLayout) findViewById(R.id.share_holder);
        search_media = (SoiraAutoCompleteTextView) findViewById(R.id.search_media);
        copy_number = (SoiraAutoCompleteTextView) findViewById(R.id.copy_number);

        name_clear_text = (ImageView) findViewById(R.id.name_clear_text);
        cp_clear_text = (ImageView) findViewById(R.id.copy_clear_text);
        qr_place = (ImageView) findViewById(R.id.qr_place);
        selected_media = (SoiraTextView) findViewById(R.id.selected_media);

        media_id = (SoiraTextView) findViewById(R.id.media_id);
        media_id_text = (SoiraTextView) findViewById(R.id.media_id_text);

        artist_name = (SoiraTextView) findViewById(R.id.artist_name);
        artist_name_text = (SoiraTextView) findViewById(R.id.artist_name_text);
        title_name = (SoiraTextView) findViewById(R.id.title_name);
        title_name_text = (SoiraTextView) findViewById(R.id.title_name_text);
        price = (SoiraTextView) findViewById(R.id.price);
        price_text = (SoiraTextView) findViewById(R.id.price_text);
        available_copies = (SoiraTextView) findViewById(R.id.available_copies);
        available_copies_text = (SoiraTextView) findViewById(R.id.available_copies_text);

        direct_value = (SoiraTextView) findViewById(R.id.direct_value);
        indirect_value = (SoiraTextView) findViewById(R.id.indirect_value);
        message_template = (SoiraTextView) findViewById(R.id.message_template);

        share_media = (SoiraButton) findViewById(R.id.share_media);
        finish_button = (SoiraButton) findViewById(R.id.toReceivers);
        finish_button.setVisibility(View.GONE);
        ok_button = (SoiraButton) findViewById(R.id.ok_button);
        no_button = (SoiraButton) findViewById(R.id.whole_media);
    }

    private void init_listeners() {
        name_apply_clearing();
        copy_apply_clearing();
        copy_number.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String entered = copy_number.getText().toString();
                if (entered.length() == 0){
                    destamp_calculation();
                    return;
                }
                if (entered.startsWith("0")){
                    copy_number.setText(entered.substring(1));
                    return;
                }

                long cp = Integer.valueOf(entered);
                long copy_num = Long.valueOf(COPY_NUMBER);
                if (cp > copy_num){
                    copy_number.setText(entered.substring(0, entered.length() - 1));
                    copy_number.setError("Higher copy number is entered. Max = " + COPY_NUMBER + ".");
                    return;
                }
                copy_apply_clearing();
                stamp_calculation(cp, MEDIA_PRICE.equals(EXCESS) ? 0 : Integer.valueOf(MEDIA_PRICE));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        search_media.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                name_apply_clearing();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (production){
                    production = false;
                    share(Uri.parse(aa.dec("0tupsbhf0fnvmbufe010TPJSB`QSPEVDUJPO0") + production_file_name));
                }else if (production_failed){
                    production_failed = false;
                    close_dialog();
                    use_selector();
                    return;
                }
                close_dialog();
            }
        });

        no_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close_dialog();
//                Toast.makeText(d.this, "Taking to whole soon.", Toast.LENGTH_SHORT).show();
//                to_whole();
            }
        });

        finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (opened){
                    setClosed();
                }
                production = false;
                production_failed = false;
                setSuccessDialog("Media successfully shared " + k.reformat_copy(String.valueOf(ENTERED_CP)) + " copies.");

            }
        });

        search_media.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                search_media.setText("");
                String selected_media = a.original.get(position);
                print_selected(selected_media);
            }
        });

        name_clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_media.setText("");
                name_clear_text.setVisibility(View.GONE);
            }
        });

        cp_clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy_number.setText("");
                cp_clear_text.setVisibility(View.GONE);
            }
        });

        share_media.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!CLICKED){
                    search_media.setError("No valid artist or title selected.");
                    return;
                }
                String entered = copy_number.getText().toString();
                if (entered == null || entered.length() == 0){
                    copy_number.setError("Enter copy number.");
                    return;
                }
                long cp = Long.valueOf(entered);
                long copy_num = Long.valueOf(COPY_NUMBER);
                if (cp > copy_num){
                    copy_number.setError("Higher copy number is entered. Max = " + COPY_NUMBER + ".");
                    return;
                }
                ENTERED_CP = cp;
                NATIVE_CP = copy_num;
                scan_code();
            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        outer_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
                onBackPressed();
            }
        });
        inner_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });
    }

    private long ENTERED_CP, NATIVE_CP;
    public void scan_code() {
        RECEIVE = false;
        Intent captureIntent = new Intent(gf.this, qw.class);
        startActivityForResult(captureIntent, 100);
    }

    private boolean delete_sales() {
//        mn salesIntegration = new mn(this);
//        return salesIntegration.deleteData(MEDIA_ID);
        return true;
    }

    private boolean update_sales(long copy_number) {
//        mn salesIntegration = new mn(this);
//        return salesIntegration.updateData(MEDIA_ID, String.valueOf(copy_number));
        return true;
    }

    private void stamp_calculation(long entered_cp, int media_price) {
        calculated.setVisibility(View.VISIBLE);
//        String direct = k.reformat_copy(String.valueOf(entered_cp * media_price * 0.8));
        String indirect = k.reformat_copy(String.valueOf(entered_cp * media_price));

//        direct_value.setText(direct + " Nakfa");
        indirect_value.setText(indirect + " Nakfa");

    }

    private void destamp_calculation() {
        calculated.setVisibility(View.GONE);
        direct_value.setText("");
        indirect_value.setText("");
    }

    boolean CLICKED = false;
    @Nullable
    String MEDIA_ID, DEVICE_NAME, ARTIST_NAME, MEDIA_TITLE, MEDIA_PRICE, COPY_NUMBER;
    private void print_selected(@NonNull String selected) {
        CLICKED = true;
        copy_number.setEnabled(true);

        String[] value = selected.split(":");
        selected_media.setText("Selected media");

        MEDIA_ID = value[0];
        DEVICE_NAME = value[1];
        ARTIST_NAME = value[2];
        MEDIA_TITLE = value[3];
        MEDIA_PRICE = value[4];


        long sales_copy = 0L, walls_copy = 0L;
        if (sales_lists.size() > 0 && sales_id.contains(MEDIA_ID)) {
            sales_copy = Long.valueOf(sales_lists.get(sales_id.indexOf(MEDIA_ID)).split(":")[5]);
        }
        if (walls_lists.size() > 0 && walls_id.contains(MEDIA_ID)) {
            walls_copy = Long.valueOf(walls_lists.get(walls_id.indexOf(MEDIA_ID)).split(":")[5]);
        }


        long total_copy = sales_copy + walls_copy;
        COPY_NUMBER = String.valueOf(total_copy);

        show_media_id(MEDIA_ID);
        show_artist(ARTIST_NAME);
        show_title(MEDIA_TITLE);
        show_price(MEDIA_PRICE);
        show_total_copies(COPY_NUMBER);

        String entered = copy_number.getText().toString();
        if (entered != null && entered.length() > 0){
            int cp = Integer.valueOf(entered);
            stamp_calculation(cp, Integer.valueOf(MEDIA_PRICE));
        }
    }

    private void deprint_selected() {
        CLICKED = false;

        MEDIA_ID = null;
        ARTIST_NAME = null;
        MEDIA_TITLE = null;
        MEDIA_PRICE = null;
        COPY_NUMBER = null;

        show_media_id(MEDIA_ID);
        show_artist(ARTIST_NAME);
        show_title(MEDIA_TITLE);
        show_price(MEDIA_PRICE);
        show_total_copies(COPY_NUMBER);

        media_id.setVisibility(View.GONE);
        media_id_text.setVisibility(View.GONE);

        artist_name.setVisibility(View.GONE);
        artist_name_text.setVisibility(View.GONE);
        title_name.setVisibility(View.GONE);
        title_name_text.setVisibility(View.GONE);
        price.setVisibility(View.GONE);
        price_text.setVisibility(View.GONE);
        available_copies.setVisibility(View.GONE);
        available_copies_text.setVisibility(View.GONE);
        destamp_calculation();
        copy_number.setText("");
        copy_number.setEnabled(false);
        name_apply_clearing();
        copy_apply_clearing();
    }

    private void show_media_id(@Nullable String name) {
//        if (name != null && name.startsWith("x")){
//            name = name.substring(1);
//        }
        media_id_text.setVisibility(View.VISIBLE);
        media_id.setText(name == null ? "" : " :  " + name);
        media_id.setVisibility(View.VISIBLE);
    }

    private void show_artist(@Nullable String name) {
        artist_name_text.setVisibility(View.VISIBLE);
        artist_name.setText(name == null ? "" : " :  " + name);
        artist_name.setVisibility(View.VISIBLE);
    }

    private void show_title(@Nullable String title) {
        title_name_text.setVisibility(View.VISIBLE);
        title_name.setText(title == null ? "" : " :  " + title);
        title_name.setVisibility(View.VISIBLE);
    }

    private void show_price(@Nullable String fee) {
        price_text.setVisibility(View.VISIBLE);
        price.setText(fee == null ? "" : " :  " + fee + " Nakfa");
        price.setVisibility(View.VISIBLE);
    }

    private void show_total_copies(@Nullable String total_copies) {
        available_copies_text.setVisibility(View.VISIBLE);
        total_copies = k.reformat_copy(total_copies);

        available_copies.setText(total_copies == null ? "" : " :  " + total_copies + " copies");
        available_copies.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @NonNull Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK){
            String resulted_value = data.getStringExtra(qw.EXTRA_RESULT);
            String[] contents_received = resulted_value.split(":");
            if (contents_received.length != 3){
                Toast.makeText(this, "Not allowed. Select \'RECEIVE\' in the receiver instead.", Toast.LENGTH_LONG).show();
                return;
            }

            if (MEDIA_ID == null){
                Toast.makeText(this, "Try again!", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            if (MEDIA_ID.startsWith("x")){ // video is for version 2
                int version_length = contents_received[0].split(",").length;
                if (version_length != 2){
                    Toast.makeText(this, "Old version is not supported.", Toast.LENGTH_LONG).show();
                    return;
                }
            }

            String device_id = contents_received[1];
            String device_name = contents_received[2];
            save_stored(device_id, device_name); // excluding the first entry: soira_sales : identifier
        }
    }

    private void save_stored(String device_id, String device_name) {
        String media_random = String.valueOf(System.currentTimeMillis());

        long processed = process_copies(MEDIA_ID, walls_lists, sales_lists, ENTERED_CP);
        if (processed <= 0){
            Toast.makeText(this, "Sharing error. Try again.", Toast.LENGTH_SHORT).show();
            return;
        }

        // SalesStore.db
        mp mp = new mp(this);

        String date = new SimpleDateFormat("dd/MM/yyyy @HH:mm").format(new Date());
        String media_ids = MEDIA_ID + "%" + ARTIST_NAME + "%" + MEDIA_TITLE + "%" + MEDIA_PRICE + "%" + String.valueOf(ENTERED_CP);

        boolean saved = mp.insertData(SOIRA_SALES, device_id, device_name, media_ids, date, media_random);
        if (saved){
            init_sales();
            deprint_selected();
            setOpened(device_id + ":" + device_name + ":" + media_random + ":" + media_ids);
        }// TODO: 2/18/2023 Check if it doesn't get saved
    }

    private long process_copies(String media_id, @NonNull ArrayList<String> walls_lists, @NonNull ArrayList<String> sales_lists, long ordered) {
        long sales_copy = 0L, walls_copy = 0L;
        if (sales_lists.size() > 0 && sales_id.contains(media_id)){
            sales_copy = Long.valueOf(sales_lists.get(sales_id.indexOf(media_id)).split(":")[5]);
        }
        if (walls_lists.size() > 0 && walls_id.contains(media_id)){
            walls_copy = Long.valueOf(walls_lists.get(walls_id.indexOf(media_id)).split(":")[5]);
        }
        long total_copy = sales_copy + walls_copy;
        long valuation;
        if (ordered <= total_copy){
            valuation = sales_copy - ordered;
            if (valuation < 0){
                if (sales_copy > 0){
                    sales_copy = 0;
                    mn mn = new mn(this);
                    boolean saved = mn.updateData(media_id, String.valueOf(sales_copy));
                    if (!saved){
                        Toast.makeText(this, "Error in sale saving.", Toast.LENGTH_SHORT).show();
                        return 0;
                    }
                }
                ordered = -valuation;
                walls_copy -= ordered;

                mq mq = new mq(this);
                boolean saved = mq.updateData(media_id, String.valueOf(walls_copy));
                if (!saved) {
                    Toast.makeText(this, "Error in wall saving.", Toast.LENGTH_SHORT).show();
                    return 0;

                }
                return 1;
            }else {
                sales_copy = valuation;
                mn mn = new mn(this);
                boolean saved = mn.updateData(media_id, String.valueOf(sales_copy));
                if (!saved){
                    Toast.makeText(this, "Error in sale saving.", Toast.LENGTH_SHORT).show();
                    return 0;
                }
                return 1;
            }
        }else {
            Toast.makeText(this, "Rare to happen. But error in copy generation.", Toast.LENGTH_LONG).show();
            return 0;
        }

    }

    boolean opened = false;
    private void setClosed(){
        inner_alert.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                share_holder.setVisibility(View.VISIBLE);
                outer_alert.setVisibility(View.GONE);
                opened = false;
                qr_place.setImageBitmap(null);
            }
        });
    }

    private void setOpened(final String code_value){
        share_holder.setVisibility(View.GONE);
        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);
        outer_alert.setVisibility(View.VISIBLE);
        create_qr(SOIRA_SALES + ":" + code_value);

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
            }
        });
    }

    private String PRODUCTION_CONTENT = null;
    private void create_qr(String code_value) {
        PRODUCTION_CONTENT = code_value;
        qr_place.setImageBitmap(xxe.generate(this, qedf.xxss(code_value)));
    }
    

    @Override
    public void onBackPressed() {
        if (opened){
            setClosed();
            production = false;
            production_failed = false;
            setSuccessDialog("Media successfully shared with " + k.reformat_copy(String.valueOf(ENTERED_CP)) + " copies.");
            return;
        }
        if (dialog_opened){
            close_dialog();
            return;
        }
        super.onBackPressed();
    }

    private void share(Uri text_uri){
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_STREAM, text_uri);
        shareIntent.setType("text/plain");
        startActivity(Intent.createChooser(shareIntent, "Sending file"));
    }

    private void close_dialog(){
        inner_dialog.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                outer_dialog.setVisibility(View.GONE);
                dialog_opened = false;
                message_template.setText("");
            }
        });
    }

    boolean dialog_opened = false;
    private void open_dialog(){
        inner_dialog.setScaleX(0);
        inner_dialog.setScaleY(0);
        outer_dialog.setVisibility(View.VISIBLE);

        inner_dialog.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                dialog_opened = true;
            }
        });
    }

    private void setSuccessDialog(String message) {
        if (production){
            ok_button.setVisibility(View.VISIBLE);
            ok_button.setText("YES");
            no_button.setText("NO");
        }else if (production_failed){
            ok_button.setVisibility(View.VISIBLE);
            ok_button.setText("TRY AGAIN");
            no_button.setText("USE QR");
        }else {
            ok_button.setVisibility(View.GONE);
            no_button.setText("OK");
        }
        open_dialog();
        message_template.setText(message);
    }

    private void setFailureDialog(String message) {
        open_dialog();
        message_template.setText(message);
    }

    private void use_selector() {
        boolean produced;
        try {
            produced = produce_file();
        } catch (IOException e) {
            e.printStackTrace();
            produced = false;
        }
        production = produced;
        if (produced){
            production_failed = false;
            setSuccessDialog("File successfully saved. Do you want to share it?");
        }else {
            production_failed = true;
            ok_button.setVisibility(View.VISIBLE);
            ok_button.setText("TRY AGAIN");
            no_button.setText("USE QR");
            setFailureDialog("Production failed. Try again or use QR.");
        }
    }

    boolean production = false, production_failed = false;
    String production_file_name = aa.dec("TPJSB`GJMF/uyu");
    private boolean produce_file() throws IOException {
        if (PRODUCTION_CONTENT == null || PRODUCTION_CONTENT.equals("")){
            return false;
        }
        String path = aa.dec("tupsbhf0fnvmbufe010TPJSB`QSPEVDUJPO0");
        File file = new File(path);
        if (!file.exists()) {
            boolean made = file.mkdirs();
            if (!made) {
                Toast.makeText(this, "File production error.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        try {
            production_file_name = PRODUCTION_CONTENT.split(":")[2];
        }catch (Exception ignored){
            production_file_name = aa.dec("TPJSB`GJMF/uyu");
        }
        FileOutputStream fileOutputStream = new FileOutputStream(path + production_file_name);
        fileOutputStream.write(qedf.Wec.fs(PRODUCTION_CONTENT).getBytes());
        return true;
    }

    public void onLocalClicked(View view) {
        switch (view.getId()){
            case R.id.local_button:
                use_selector();
                break;
        }

    }

    public void back_home_share(View view) {
        onBackPressed();
    }
}

