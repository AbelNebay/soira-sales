package com.aaa.datamatrix;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * The below database helper is used to store the given path according to their newly added one!
 * &amp; setting_layout bit more_dark.... PEACE!
 * */
public class mq extends SQLiteOpenHelper{
    private static final String SOIRAWALLS_CODES = "SOIRAWALLS_CODES";


    private static final String DATABASE_NAME = "SOIRAWALLS_INTEGRATION.db";
    private final String TABLE_NAME;
    public static final String MEDIA_ID = "MEDIA_ID";
    public static final String DEVICE_NAME = "DEVICE_NAME";
    public static final String ARTIST_NAME = "ARTIST_NAME";
    public static final String MEDIA_TITLE = "MEDIA_TITLE";
    public static final String PRICE = "PRICE";
    public static final String COPY_NUMBER = "COPY_NUMBER";

    /**
     * mn constructor with
     * @param context
     * Author       : Abel Nebay
     * College      : Mai-Nefhi College of Science
     * Department   : Applied Biology IV Year
     * E-mail       : abelnebay555@gmail.com
     * Website      : https://www.leafpedia.com
     * Company      : Leaf Pedia, Inc.
     * Foundation   : SoiraPlayer, Inc.
     * Tel          : +291-7276-749
     * Year         : 2023 - Tesseney, Asmara - Eritrea, Norther East Africa @Earth {#3 Planet}
     * */
    mq(Context context, String TABLE_NAME) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = TABLE_NAME;
    }

    public mq(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = SOIRAWALLS_CODES;
    }

    /**
     * onCreate for creating the existing or new table by the name
     * */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + MEDIA_ID + " TEXT PRIMARY KEY, " + DEVICE_NAME + " TEXT, " + ARTIST_NAME + " TEXT, " + MEDIA_TITLE + " TEXT, " + PRICE + " TEXT, " + COPY_NUMBER + " TEXT)");

    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
    }

    public Cursor getAllData(){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME, null);
    }

    @Nullable
    public String getCurrentCopyAt(String media_id){
        Cursor cursor = getDataAt(media_id);
        String value = null;
        if (cursor != null && cursor.moveToFirst()){
            value = cursor.getString(cursor.getColumnIndex(COPY_NUMBER));
            cursor.close();
        }
        return value;
    }

    @Nullable
    public String getValueAt(String media_id, String column){
        Cursor cursor = getDataAt(media_id);
        String value = null;
        if (cursor != null && cursor.moveToFirst()){
            value = cursor.getString(cursor.getColumnIndex(column));
            cursor.close();
        }
        return value;
    }

    public boolean updateWhole(String media_id, String device_name, String artist_name, String media_title, String media_price, String copy_number){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DEVICE_NAME, device_name);
        contentValues.put(ARTIST_NAME, artist_name);
        contentValues.put(MEDIA_TITLE, media_title);
        contentValues.put(PRICE, media_price);
        contentValues.put(COPY_NUMBER, copy_number);
        int result = database.update(TABLE_NAME, contentValues, MEDIA_ID + "=?", new String[]{media_id});
        database.close();
        return result > 0;
    }


    public Cursor getDataAt(String media_id){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME + " where " + MEDIA_ID + " ='" + media_id + "'", null);
    }

    public boolean updateData(String media_id, String copy_number){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COPY_NUMBER, copy_number);
        int result = database.update(TABLE_NAME, contentValues, MEDIA_ID + "=?", new String[]{media_id});
        database.close();
        return result > 0;
    }

    public boolean insertData(String media_id, String device_name, String artist_name, String media_title, String media_price, String copy_number){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MEDIA_ID, media_id);
        contentValues.put(DEVICE_NAME, device_name);
        contentValues.put(ARTIST_NAME, artist_name);
        contentValues.put(MEDIA_TITLE, media_title);
        contentValues.put(PRICE, media_price);
        contentValues.put(COPY_NUMBER, copy_number);
        long result = database.insert(TABLE_NAME, null, contentValues);
        database.close();
        return result != -1;
    }


    public boolean deleteData(String media_id){
        SQLiteDatabase database = this.getWritableDatabase();
        int i =  database.delete(TABLE_NAME, MEDIA_ID + "=?", new String[]{media_id});
        database.close();
        return i > 0;
    }




}
