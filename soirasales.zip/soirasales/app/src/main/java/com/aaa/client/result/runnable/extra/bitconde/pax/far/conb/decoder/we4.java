package com.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder;

import java.util.ArrayList;
import java.util.Arrays;

public class we4 {

    public static final ArrayList<String> caps = new ArrayList<>();

    static {

        String[] caps_ext = new String[]{
                " ", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        caps.addAll(Arrays.asList(caps_ext));
    }

}
