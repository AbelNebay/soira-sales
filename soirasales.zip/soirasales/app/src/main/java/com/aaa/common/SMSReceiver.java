package com.aaa.common;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.aa.aaa.aaa.datamatrix.encoder.a;

import static com.aa.aaa.aaa.datamatrix.encoder.a.sms_ongoing;

public class SMSReceiver extends BroadcastReceiver{
    public static String TAG = "android.provider.Telephony.SMS_RECEIVED";
    a a;

    public SMSReceiver(){}

    public SMSReceiver(a a){
        this.a = a;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && intent.getAction().equals(TAG)){
            if (!sms_ongoing && this.a != null){
                this.a.requestSmsPermission();
            }
        }
    }
}
