package com.aaa;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * The below database helper is used to store the given path according to their newly added one!
 * &amp; setting_layout bit more_dark.... PEACE!
 * */
public class Comings extends SQLiteOpenHelper{
    private static final String SOIRASALES_CODES = "SOIRACOMINGS_STORE";


    private static final String DATABASE_NAME = "SOIRACOMINGS_STORE.db";
    private final String TABLE_NAME;
    private static final String UPCOMING = "UPCOMING";

    /**
     * mn constructor with
     * @param context
     * Author       : Abel Nebay
     * College      : Mai-Nefhi College of Science
     * Department   : Applied Biology IV Year
     * E-mail       : abelnebay555@gmail.com
     * Website      : https://www.leafpedia.com
     * Company      : Leaf Pedia, Inc.
     * Foundation   : SoiraPlayer, Inc.
     * Tel          : +291-7276-749
     * Year         : 2023 - Tesseney, Asmara - Eritrea, Norther East Africa @Earth {#3 Planet}
     * */
    Comings(Context context, String TABLE_NAME) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = TABLE_NAME;
    }

    public Comings(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = SOIRASALES_CODES;
    }

    /**
     * onCreate for creating the existing or new table by the name
     * */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + UPCOMING + " TEXT PRIMARY KEY)");
    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
    }

    public Cursor getAllData(){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME, null);
    }


    @Nullable
    public String getValueAt(String entry){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("select * from " + TABLE_NAME + " where " + UPCOMING + "=" + entry, null);
        if (cursor != null && cursor.moveToFirst()){
            String result = cursor.getString(0);
            cursor.close();
            return result;
        }
        return null;
    }

    public boolean insertData(String media_random){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(UPCOMING, media_random);
        long result = database.insert(TABLE_NAME, null, contentValues);
        database.close();
        return result != -1;
    }

    public boolean deleteData(String media_random){
        SQLiteDatabase database = this.getWritableDatabase();
        int i =  database.delete(TABLE_NAME, UPCOMING + "=?", new String[]{media_random});
        database.close();
        return i > 0;
    }

}
